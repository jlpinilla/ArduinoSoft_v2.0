# BACKUP COMPLETO - SUITE AMBIENTAL

Este archivo contiene un backup completo del sistema Suite Ambiental.

## CONTENIDO

- **proyecto/**: Todos los archivos del proyecto web
- **database/**: Backup de la base de datos
  - `database_dump.sql`: Dump completo de la base de datos
  - `restore.sh`: Script de restauración para Linux/Mac
  - `restore.bat`: Script de restauración para Windows

## INSTRUCCIONES DE RESTAURACIÓN

### 1. Restaurar archivos del proyecto
Copie todos los archivos de la carpeta `proyecto/` a su servidor web.

### 2. Restaurar base de datos
1. Cree una nueva base de datos en su servidor MySQL
2. Ejecute el comando:
   ```
   mysql -u [usuario] -p [nombre_base_datos] < database/database_dump.sql
   ```
3. O use los scripts incluidos modificando las credenciales

### 3. Configurar conexión
Edite el archivo `config.ini` con las credenciales de su nueva base de datos.

## INFORMACIÓN ADICIONAL

- Fecha de backup: 2025-06-18 10:46:28
- Usuario: admin
- Versión: 3.1
