#!/bin/bash
# Script de restauración de base de datos
# Suite Ambiental - Generado el 2025-06-18 10:46:28

echo "Restaurando base de datos..."
mysql -u [USUARIO] -p [BASE_DE_DATOS] < database_dump.sql
echo "Restauración completada"
