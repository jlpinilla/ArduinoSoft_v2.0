-- =====================================================
-- BACKUP DE BASE DE DATOS - SUITE AMBIENTAL
-- Generado el: 2025-06-18 10:46:28
-- Base de datos: suite_ambiental
-- Usuario: admin
-- =====================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = '+00:00';

-- Estructura de tabla `configuracion`
DROP TABLE IF EXISTS `configuracion`;
CREATE TABLE `configuracion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `seccion` varchar(50) NOT NULL COMMENT 'Sección de configuración',
  `clave` varchar(100) NOT NULL COMMENT 'Clave de configuración',
  `valor` text NOT NULL COMMENT 'Valor de configuración',
  `descripcion` text DEFAULT NULL COMMENT 'Descripción del parámetro',
  `tipo` enum('string','int','float','boolean','json') DEFAULT 'string' COMMENT 'Tipo de dato',
  `fecha_creacion` timestamp NULL DEFAULT current_timestamp(),
  `fecha_actualizacion` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_seccion_clave` (`seccion`,`clave`),
  KEY `idx_seccion` (`seccion`),
  KEY `idx_tipo` (`tipo`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Tabla de configuración del sistema';

-- Datos de la tabla `configuracion`
INSERT INTO `configuracion` (`id`, `seccion`, `clave`, `valor`, `descripcion`, `tipo`, `fecha_creacion`, `fecha_actualizacion`) VALUES
('1', 'sistema', 'version', '1.0', 'Versión del sistema Suite Ambiental', 'string', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('2', 'sistema', 'nombre', 'Suite Ambiental', 'Nombre del sistema', 'string', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('3', 'sistema', 'timezone', '+01:00', 'Zona horaria del sistema (España UTC+1)', 'string', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('4', 'alertas', 'temperatura_max', '25', 'Temperatura máxima antes de alerta (°C)', 'float', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('5', 'alertas', 'humedad_max', '48', 'Humedad relativa máxima antes de alerta (%)', 'float', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('6', 'alertas', 'ruido_max', '35', 'Nivel de ruido máximo antes de alerta (dB)', 'float', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('7', 'alertas', 'co2_max', '1000', 'Concentración de CO2 máxima antes de alerta (ppm)', 'int', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('8', 'alertas', 'lux_min', '195', 'Iluminación mínima antes de alerta (lux)', 'int', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('9', 'mantenimiento', 'dias_retencion_registros', '180', 'Días de retención para registros de sensores', 'int', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('10', 'mantenimiento', 'dias_retencion_logs', '90', 'Días de retención para logs del sistema', 'int', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('11', 'api', 'max_registros_por_minuto', '60', 'Máximo de registros por minuto por dispositivo', 'int', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('12', 'api', 'timeout_dispositivo_horas', '1', 'Horas para considerar dispositivo inactivo', 'int', '2025-06-10 16:43:03', '2025-06-10 16:43:03');

-- Estructura de tabla `dispositivos`
DROP TABLE IF EXISTS `dispositivos`;
CREATE TABLE `dispositivos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL COMMENT 'Identificador único del dispositivo',
  `ubicacion` varchar(255) NOT NULL COMMENT 'Ubicación física del dispositivo',
  `direccion_ip` varchar(45) NOT NULL COMMENT 'Dirección IP del dispositivo (IPv4/IPv6)',
  `direccion_mac` varchar(17) NOT NULL COMMENT 'Dirección MAC del dispositivo',
  `descripcion` text DEFAULT NULL COMMENT 'Descripción adicional del dispositivo',
  `fecha_instalacion` date DEFAULT NULL COMMENT 'Fecha de instalación del dispositivo',
  `fecha_creacion` timestamp NULL DEFAULT current_timestamp() COMMENT 'Fecha de registro en el sistema',
  `fecha_actualizacion` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `activo` tinyint(1) DEFAULT 1 COMMENT 'Si el dispositivo está activo',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nombre` (`nombre`),
  KEY `idx_ubicacion` (`ubicacion`),
  KEY `idx_ip` (`direccion_ip`),
  KEY `idx_activo` (`activo`),
  KEY `idx_fecha_creacion` (`fecha_creacion`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Tabla de dispositivos/sensores Arduino registrados';

-- Datos de la tabla `dispositivos`
INSERT INTO `dispositivos` (`id`, `nombre`, `ubicacion`, `direccion_ip`, `direccion_mac`, `descripcion`, `fecha_instalacion`, `fecha_creacion`, `fecha_actualizacion`, `activo`) VALUES
('6', 'Sensor-F702ECC5', 'Saala2', '192.168.1.79', '30:C6:F7:02:EC:C5', NULL, NULL, '2025-06-15 00:16:09', '2025-06-16 16:51:00', '1');

-- Estructura de tabla `logs_sistema`
DROP TABLE IF EXISTS `logs_sistema`;
CREATE TABLE `logs_sistema` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nivel` enum('DEBUG','INFO','WARNING','ERROR','CRITICAL') NOT NULL DEFAULT 'INFO',
  `categoria` varchar(50) NOT NULL COMMENT 'Categoría del log (login, api, admin, etc)',
  `mensaje` text NOT NULL COMMENT 'Mensaje del log',
  `usuario_id` int(11) DEFAULT NULL COMMENT 'Usuario relacionado (si aplica)',
  `direccion_ip` varchar(45) DEFAULT NULL COMMENT 'Dirección IP del cliente',
  `user_agent` text DEFAULT NULL COMMENT 'User Agent del navegador',
  `datos_adicionales` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Datos adicionales en formato JSON' CHECK (json_valid(`datos_adicionales`)),
  `fecha_hora` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_nivel_fecha` (`nivel`,`fecha_hora`),
  KEY `idx_categoria_fecha` (`categoria`,`fecha_hora`),
  KEY `idx_usuario_fecha` (`usuario_id`,`fecha_hora`),
  KEY `idx_fecha_hora` (`fecha_hora`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Tabla de logs del sistema';

-- Datos de la tabla `logs_sistema`
INSERT INTO `logs_sistema` (`id`, `nivel`, `categoria`, `mensaje`, `usuario_id`, `direccion_ip`, `user_agent`, `datos_adicionales`, `fecha_hora`) VALUES
('1', 'INFO', 'usuario', 'Usuario creado', '1', NULL, NULL, '{\"usuario\": \"admin\", \"rol\": \"admin\"}', '2025-06-10 16:43:02'),
('2', 'INFO', 'usuario', 'Usuario creado', '2', NULL, NULL, '{\"usuario\": \"operador1\", \"rol\": \"operador\"}', '2025-06-10 16:43:02'),
('3', 'INFO', 'usuario', 'Usuario creado', '3', NULL, NULL, '{\"usuario\": \"demo\", \"rol\": \"operador\"}', '2025-06-10 16:43:02'),
('4', 'INFO', 'dispositivo', 'Dispositivo modificado', NULL, NULL, NULL, '{\"dispositivo\": \"Sensor01\", \"cambios\": {\"activo_anterior\": 1, \"activo_nuevo\": 1, \"ubicacion_anterior\": \"Oficina Principal - Administración\", \"ubicacion_nueva\": \"SteamRoom\"}}', '2025-06-11 13:03:38'),
('5', 'INFO', 'usuario', 'Usuario creado', '4', NULL, NULL, '{\"usuario\": \"demo\", \"rol\": \"operador\"}', '2025-06-11 13:26:33'),
('6', 'INFO', 'dispositivo', 'Dispositivo modificado', NULL, NULL, NULL, '{\"dispositivo\": \"Sensor01\", \"cambios\": {\"activo_anterior\": 1, \"activo_nuevo\": 1, \"ubicacion_anterior\": \"SteamRoom\", \"ubicacion_nueva\": \"Sala de Superación\"}}', '2025-06-11 13:27:25'),
('7', 'INFO', 'usuario', 'Usuario creado', '5', NULL, NULL, '{\"usuario\": \"demo\", \"rol\": \"operador\"}', '2025-06-11 17:44:58'),
('8', 'INFO', 'usuario', 'Usuario creado', '6', NULL, NULL, '{\"usuario\": \"mmontarroso\", \"rol\": \"operador\"}', '2025-06-11 18:30:44'),
('9', 'INFO', 'dispositivo', 'Dispositivo modificado', NULL, NULL, NULL, '{\"dispositivo\": \"Sensor01\", \"cambios\": {\"activo_anterior\": 1, \"activo_nuevo\": 1, \"ubicacion_anterior\": \"Sala de Superación\", \"ubicacion_nueva\": \"Sala Steam\"}}', '2025-06-11 18:31:18'),
('10', 'INFO', 'dispositivo', 'Dispositivo modificado', NULL, NULL, NULL, '{\"dispositivo\": \"Sensor03\", \"cambios\": {\"activo_anterior\": 1, \"activo_nuevo\": 1, \"ubicacion_anterior\": \"Almacén - Planta Baja\", \"ubicacion_nueva\": \"Planta Baja\"}}', '2025-06-15 00:53:56'),
('11', 'INFO', 'dispositivo', 'Dispositivo modificado', NULL, NULL, NULL, '{\"dispositivo\": \"Sensor04\", \"cambios\": {\"activo_anterior\": 1, \"activo_nuevo\": 1, \"ubicacion_anterior\": \"Sala de Reuniones Ejecutiva\", \"ubicacion_nueva\": \"Sala de Reuniones\"}}', '2025-06-15 00:54:05'),
('12', 'INFO', 'dispositivo', 'Dispositivo modificado', NULL, NULL, NULL, '{\"dispositivo\": \"Sensor05\", \"cambios\": {\"activo_anterior\": 1, \"activo_nuevo\": 1, \"ubicacion_anterior\": \"Pasillo Principal - Recepción\", \"ubicacion_nueva\": \"Recepción\"}}', '2025-06-15 00:54:13'),
('13', 'INFO', 'dispositivo', 'Dispositivo modificado', NULL, NULL, NULL, '{\"dispositivo\": \"Sensor02\", \"cambios\": {\"activo_anterior\": 1, \"activo_nuevo\": 1, \"ubicacion_anterior\": \"Laboratorio de Investigación\", \"ubicacion_nueva\": \"Laboratorio\"}}', '2025-06-15 00:54:23'),
('14', 'INFO', 'dispositivo', 'Dispositivo modificado', NULL, NULL, NULL, '{\"dispositivo\": \"Sensor-F702ECC5\", \"cambios\": {\"activo_anterior\": 1, \"activo_nuevo\": 1, \"ubicacion_anterior\": \"Sala_Steam\", \"ubicacion_nueva\": \"Staff\"}}', '2025-06-15 02:01:25'),
('15', 'INFO', 'dispositivo', 'Dispositivo modificado', NULL, NULL, NULL, '{\"dispositivo\": \"Sensor-F702ECC5\", \"cambios\": {\"activo_anterior\": 1, \"activo_nuevo\": 1, \"ubicacion_anterior\": \"Staff\", \"ubicacion_nueva\": \"Saala2\"}}', '2025-06-16 16:51:00');

-- Estructura de tabla `registros`
DROP TABLE IF EXISTS `registros`;
CREATE TABLE `registros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sensor_id` varchar(50) DEFAULT NULL COMMENT 'ID del sensor que envía los datos',
  `temperatura` decimal(5,2) DEFAULT NULL COMMENT 'Temperatura en grados Celsius (-99.99 a 999.99)',
  `humedad` decimal(5,2) DEFAULT NULL COMMENT 'Humedad relativa en porcentaje (0.00 a 100.00)',
  `ruido` decimal(5,2) DEFAULT NULL COMMENT 'Nivel de ruido en decibelios (0.00 a 150.00)',
  `co2` int(11) DEFAULT NULL COMMENT 'Concentración de CO2 en ppm (0 a 50000)',
  `lux` int(11) DEFAULT NULL COMMENT 'Iluminación en lux (0 a 100000)',
  `fecha_hora` datetime DEFAULT NULL COMMENT 'Fecha y hora del registro',
  `alerta_temperatura` tinyint(1) GENERATED ALWAYS AS (`temperatura` > 25) STORED COMMENT 'Alerta por temperatura alta',
  `alerta_humedad` tinyint(1) GENERATED ALWAYS AS (`humedad` > 48) STORED COMMENT 'Alerta por humedad alta',
  `alerta_ruido` tinyint(1) GENERATED ALWAYS AS (`ruido` > 35) STORED COMMENT 'Alerta por ruido alto',
  `alerta_co2` tinyint(1) GENERATED ALWAYS AS (`co2` > 1000) STORED COMMENT 'Alerta por CO2 alto',
  `alerta_iluminacion` tinyint(1) GENERATED ALWAYS AS (`lux` < 195) STORED COMMENT 'Alerta por iluminación baja',
  `estado` enum('normal','alerta','critico') GENERATED ALWAYS AS (case when (`temperatura` > 25) + (`humedad` > 48) + (`ruido` > 35) + (`co2` > 1000) + (`lux` < 195) >= 3 then 'critico' when (`temperatura` > 25) + (`humedad` > 48) + (`ruido` > 35) + (`co2` > 1000) + (`lux` < 195) >= 1 then 'alerta' else 'normal' end) STORED COMMENT 'Estado general del registro',
  PRIMARY KEY (`id`),
  KEY `idx_sensor_fecha` (`sensor_id`,`fecha_hora`),
  KEY `idx_fecha_hora` (`fecha_hora`),
  KEY `idx_sensor_id` (`sensor_id`),
  KEY `idx_estado` (`estado`),
  KEY `idx_temperatura` (`temperatura`),
  KEY `idx_humedad` (`humedad`),
  KEY `idx_ruido` (`ruido`),
  KEY `idx_co2` (`co2`),
  KEY `idx_lux` (`lux`),
  KEY `idx_alerta_temp` (`alerta_temperatura`,`fecha_hora`),
  KEY `idx_alerta_hum` (`alerta_humedad`,`fecha_hora`),
  KEY `idx_alerta_ruido` (`alerta_ruido`,`fecha_hora`),
  KEY `idx_alerta_co2` (`alerta_co2`,`fecha_hora`),
  KEY `idx_alerta_luz` (`alerta_iluminacion`,`fecha_hora`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Tabla de registros de datos de sensores ambientales';

-- Datos de la tabla `registros`
INSERT INTO `registros` (`id`, `sensor_id`, `temperatura`, `humedad`, `ruido`, `co2`, `lux`, `fecha_hora`, `alerta_temperatura`, `alerta_humedad`, `alerta_ruido`, `alerta_co2`, `alerta_iluminacion`, `estado`) VALUES
('42', 'Sensor-F702ECC5', '31.00', '68.00', '24.00', '576', '187', '2025-06-15 00:14:32', '1', '1', '0', '0', '1', 'critico'),
('43', 'Sensor-F702ECC5', '29.00', '68.50', '57.13', '580', '90', '2025-06-15 00:14:23', '1', '1', '1', '0', '1', 'critico'),
('44', 'Sensor-F702ECC5', '30.60', '62.50', '29.00', '498', '59', '2025-06-15 00:48:31', '1', '1', '0', '0', '1', 'critico'),
('45', 'Sensor-F702ECC5', '30.50', '62.20', '58.57', '450', '112', '2025-06-15 00:14:23', '1', '1', '1', '0', '1', 'critico'),
('46', 'Sensor-F702ECC5', '30.00', '62.50', '21.00', '500', '61', '2025-06-15 00:14:23', '1', '1', '0', '0', '1', 'critico'),
('47', 'Sensor-F702ECC5', '29.50', '64.10', '58.11', '76', '69', '2025-06-15 00:24:24', '1', '1', '1', '0', '1', 'critico'),
('48', 'Sensor-F702ECC5', '29.40', '64.10', '58.44', '82', '69', '2025-06-15 00:34:24', '1', '1', '1', '0', '1', 'critico'),
('49', 'Sensor-F702ECC5', '29.50', '64.00', '58.31', '91', '70', '2025-06-15 00:14:31', '1', '1', '1', '0', '1', 'critico'),
('50', 'Sensor-F702ECC5', '29.50', '63.60', '58.44', '73', '69', '2025-06-15 00:41:31', '1', '1', '1', '0', '1', 'critico'),
('51', 'Sensor-F702ECC5', '29.50', '63.50', '58.50', '80', '69', '2025-06-15 00:17:31', '1', '1', '1', '0', '1', 'critico'),
('52', 'Sensor-F702ECC5', '29.70', '63.60', '57.39', '83', '70', '2025-06-15 00:38:31', '1', '1', '1', '0', '1', 'critico'),
('53', 'Sensor-F702ECC5', '29.70', '64.10', '57.52', '86', '64', '2025-06-15 01:24:23', '1', '1', '1', '0', '1', 'critico'),
('54', 'Sensor-F702ECC5', '29.80', '64.10', '58.57', '75', '54', '2025-06-15 01:26:38', '1', '1', '1', '0', '1', 'critico'),
('55', 'Sensor-F702ECC5', '29.70', '64.60', '58.24', '81', '68', '2025-06-15 02:18:23', '1', '1', '1', '0', '1', 'critico'),
('56', 'Sensor-F702ECC5', '29.90', '64.70', '59.03', '125', '1036', '2025-06-15 00:14:09', '1', '1', '1', '0', '0', 'critico'),
('57', 'Sensor-F702ECC5', '30.00', '65.60', '58.57', '102', '632', '2025-06-15 00:29:53', '1', '1', '1', '0', '0', 'critico'),
('58', 'Sensor-F702ECC5', '30.00', '65.70', '20.92', '100', '1025', '2025-06-15 00:36:59', '1', '1', '0', '0', '0', 'alerta'),
('59', 'Sensor-F702ECC5', '29.90', '66.10', '21.91', '96', '65', '2025-06-15 00:38:05', '1', '1', '0', '0', '1', 'critico'),
('60', 'Sensor-F702ECC5', '29.70', '66.00', '22.30', '118', '336', '2025-06-15 02:56:23', '1', '1', '0', '0', '0', 'alerta'),
('61', 'Sensor-F702ECC5', '29.50', '67.00', '23.55', '92', '335', '2025-06-15 03:06:23', '1', '1', '0', '0', '0', 'alerta'),
('62', 'Sensor-F702ECC5', '29.50', '66.30', '24.14', '91', '335', '2025-06-15 03:16:23', '1', '1', '0', '0', '0', 'alerta'),
('63', 'Sensor-F702ECC5', '29.50', '66.40', '22.04', '403', '335', '2025-06-15 03:19:23', '1', '1', '0', '0', '0', 'alerta'),
('64', 'Sensor-F702ECC5', '29.70', '66.00', '20.46', '403', '77', '2025-06-15 03:29:23', '1', '1', '0', '0', '1', 'critico'),
('65', 'Sensor-F702ECC5', '29.50', '66.60', '22.69', '402', '101', '2025-06-15 03:39:23', '1', '1', '0', '0', '1', 'critico'),
('66', 'Sensor-F702ECC5', '29.20', '61.70', '22.69', '402', '806', '2025-06-15 03:49:23', '1', '1', '0', '0', '0', 'alerta'),
('67', 'Sensor-F702ECC5', '28.90', '62.00', '22.56', '402', '804', '2025-06-15 03:59:23', '1', '1', '0', '0', '0', 'alerta'),
('68', 'Sensor-F702ECC5', '28.70', '61.70', '21.58', '402', '804', '2025-06-15 04:09:23', '1', '1', '0', '0', '0', 'alerta'),
('69', 'Sensor-F702ECC5', '28.60', '61.40', '22.04', '402', '803', '2025-06-15 04:19:23', '1', '1', '0', '0', '0', 'alerta'),
('70', 'Sensor-F702ECC5', '28.60', '61.10', '24.27', '402', '801', '2025-06-15 04:29:23', '1', '1', '0', '0', '0', 'alerta'),
('71', 'Sensor-F702ECC5', '28.50', '60.70', '21.58', '402', '799', '2025-06-15 04:39:23', '1', '1', '0', '0', '0', 'alerta'),
('72', 'Sensor-F702ECC5', '28.50', '60.50', '23.28', '402', '795', '2025-06-15 04:49:23', '1', '1', '0', '0', '0', 'alerta'),
('73', 'Sensor-F702ECC5', '28.50', '60.40', '23.48', '402', '789', '2025-06-15 04:59:24', '1', '1', '0', '0', '0', 'alerta'),
('74', 'Sensor-F702ECC5', '28.50', '60.40', '23.41', '402', '790', '2025-06-15 05:09:24', '1', '1', '0', '0', '0', 'alerta'),
('75', 'Sensor-F702ECC5', '28.50', '60.40', '23.55', '402', '794', '2025-06-15 05:19:24', '1', '1', '0', '0', '0', 'alerta'),
('76', 'Sensor-F702ECC5', '28.50', '59.70', '24.66', '402', '794', '2025-06-15 05:29:24', '1', '1', '0', '0', '0', 'alerta'),
('77', 'Sensor-F702ECC5', '28.50', '57.80', '23.48', '403', '816', '2025-06-15 09:42:36', '1', '1', '0', '0', '0', 'alerta'),
('78', 'Sensor-F702ECC5', '28.50', '57.40', '20.79', '403', '815', '2025-06-15 09:52:37', '1', '1', '0', '0', '0', 'alerta'),
('79', 'Sensor-F702ECC5', '28.50', '57.40', '23.74', '403', '815', '2025-06-15 10:02:37', '1', '1', '0', '0', '0', 'alerta'),
('80', 'Sensor-F702ECC5', '28.70', '57.70', '22.63', '403', '1125', '2025-06-15 10:12:38', '1', '1', '0', '0', '0', 'alerta'),
('81', 'Sensor-F702ECC5', '28.70', '57.70', '22.17', '403', '1124', '2025-06-15 10:22:38', '1', '1', '0', '0', '0', 'alerta'),
('82', 'Sensor-F702ECC5', '28.70', '57.90', '21.71', '403', '1124', '2025-06-15 10:32:39', '1', '1', '0', '0', '0', 'alerta'),
('83', 'Sensor-F702ECC5', '28.70', '58.00', '24.73', '403', '1125', '2025-06-15 10:42:39', '1', '1', '0', '0', '0', 'alerta'),
('84', 'Sensor-F702ECC5', '28.70', '58.00', '21.58', '403', '1125', '2025-06-15 10:52:39', '1', '1', '0', '0', '0', 'alerta'),
('85', 'Sensor-F702ECC5', '28.90', '57.90', '21.18', '403', '1125', '2025-06-15 11:02:40', '1', '1', '0', '0', '0', 'alerta'),
('86', 'Sensor-F702ECC5', '28.80', '58.00', '24.00', '403', '1125', '2025-06-15 11:12:40', '1', '1', '0', '0', '0', 'alerta'),
('87', 'Sensor-F702ECC5', '28.90', '58.10', '24.20', '403', '1125', '2025-06-15 11:22:41', '1', '1', '0', '0', '0', 'alerta'),
('88', 'Sensor-F702ECC5', '28.90', '58.20', '23.48', '403', '1125', '2025-06-15 11:32:41', '1', '1', '0', '0', '0', 'alerta'),
('89', 'Sensor-F702ECC5', '28.90', '58.20', '20.99', '403', '1125', '2025-06-15 11:42:42', '1', '1', '0', '0', '0', 'alerta'),
('90', 'Sensor-F702ECC5', '28.70', '59.60', '22.04', '403', '1127', '2025-06-15 11:52:42', '1', '1', '0', '0', '0', 'alerta'),
('91', 'Sensor-F702ECC5', '28.60', '60.00', '22.69', '403', '1127', '2025-06-15 12:02:43', '1', '1', '0', '0', '0', 'alerta'),
('92', 'Sensor-F702ECC5', '28.90', '59.00', '29.91', '403', '1127', '2025-06-15 12:12:44', '1', '1', '0', '0', '0', 'alerta'),
('93', 'Sensor-F702ECC5', '28.90', '60.60', '23.22', '403', '1172', '2025-06-15 12:22:44', '1', '1', '0', '0', '0', 'alerta'),
('94', 'Sensor-F702ECC5', '28.50', '63.10', '22.10', '402', '1', '2025-06-15 18:36:38', '1', '1', '0', '0', '1', 'critico'),
('95', 'Sensor-F702ECC5', '28.50', '63.20', '21.38', '401', '1', '2025-06-15 18:46:37', '1', '1', '0', '0', '1', 'critico'),
('96', 'Sensor-F702ECC5', '28.60', '63.90', '25.64', '402', '20', '2025-06-15 18:56:36', '1', '1', '0', '0', '1', 'critico'),
('97', 'Sensor-F702ECC5', '28.70', '63.70', '19.35', '401', '2466', '2025-06-15 19:06:36', '1', '1', '0', '0', '0', 'alerta'),
('98', 'Sensor-F702ECC5', '28.70', '63.50', '24.14', '402', '2465', '2025-06-15 19:16:36', '1', '1', '0', '0', '0', 'alerta'),
('99', 'Sensor-F702ECC5', '28.70', '63.40', '20.53', '402', '2465', '2025-06-17 19:07:53', '1', '1', '0', '0', '0', 'alerta'),
('100', 'Sensor-F702ECC5', '28.70', '63.30', '24.53', '402', '2465', '2025-06-17 19:30:53', '1', '1', '0', '0', '0', 'alerta'),
('101', 'Sensor-F702ECC5', '28.70', '64.10', '26.30', '402', '2466', '2025-06-17 20:29:53', '1', '1', '0', '0', '0', 'alerta'),
('102', 'Sensor-F702ECC5', '29.30', '62.20', '24.53', '403', '2808', '2025-06-17 18:46:53', '1', '1', '0', '0', '0', 'alerta'),
('103', 'Sensor-F702ECC5', '29.20', '62.70', '20.59', '404', '2809', '2025-06-17 19:51:53', '1', '1', '0', '0', '0', 'alerta');

-- Estructura de tabla `usuarios`
DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL COMMENT 'Nombre de usuario único',
  `contrasena` varchar(255) NOT NULL COMMENT 'Contraseña del usuario',
  `rol` enum('admin','operador') NOT NULL DEFAULT 'operador' COMMENT 'Rol del usuario',
  `fecha_creacion` timestamp NULL DEFAULT current_timestamp() COMMENT 'Fecha de creación del usuario',
  `fecha_ultimo_acceso` timestamp NULL DEFAULT NULL COMMENT 'Último acceso al sistema',
  `activo` tinyint(1) DEFAULT 1 COMMENT 'Si el usuario está activo',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`),
  KEY `idx_rol` (`rol`),
  KEY `idx_activo` (`activo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Tabla de usuarios del sistema con autenticación local';

-- Datos de la tabla `usuarios`
INSERT INTO `usuarios` (`id`, `usuario`, `contrasena`, `rol`, `fecha_creacion`, `fecha_ultimo_acceso`, `activo`) VALUES
('1', 'admin', 'admin123', 'admin', '2025-06-10 16:43:02', '2025-06-10 16:43:02', '1'),
('5', 'demo', 'demo123', 'operador', '2025-06-11 17:44:58', NULL, '1'),
('6', 'mmontarroso', 'password123', 'operador', '2025-06-11 18:30:44', NULL, '1');

-- Estructura de tabla `v_alertas_por_hora`
DROP TABLE IF EXISTS `v_alertas_por_hora`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_alertas_por_hora` AS select cast(`registros`.`fecha_hora` as date) AS `fecha`,hour(`registros`.`fecha_hora`) AS `hora`,count(0) AS `total_registros`,sum(`registros`.`alerta_temperatura`) AS `alertas_temperatura`,sum(`registros`.`alerta_humedad`) AS `alertas_humedad`,sum(`registros`.`alerta_ruido`) AS `alertas_ruido`,sum(`registros`.`alerta_co2`) AS `alertas_co2`,sum(`registros`.`alerta_iluminacion`) AS `alertas_iluminacion`,sum(case when `registros`.`estado` = 'critico' then 1 else 0 end) AS `registros_criticos`,sum(case when `registros`.`estado` = 'alerta' then 1 else 0 end) AS `registros_alerta`,round(sum(case when `registros`.`estado` in ('critico','alerta') then 1 else 0 end) / count(0) * 100,2) AS `porcentaje_alertas` from `registros` group by cast(`registros`.`fecha_hora` as date),hour(`registros`.`fecha_hora`);

-- Datos de la tabla `v_alertas_por_hora`
INSERT INTO `v_alertas_por_hora` (`fecha`, `hora`, `total_registros`, `alertas_temperatura`, `alertas_humedad`, `alertas_ruido`, `alertas_co2`, `alertas_iluminacion`, `registros_criticos`, `registros_alerta`, `porcentaje_alertas`) VALUES
('2025-06-15', '0', '15', '15', '15', '10', '0', '12', '14', '1', '100.00'),
('2025-06-15', '1', '2', '2', '2', '2', '0', '2', '2', '0', '100.00'),
('2025-06-15', '2', '2', '2', '2', '1', '0', '1', '1', '1', '100.00'),
('2025-06-15', '3', '7', '7', '7', '0', '0', '2', '2', '5', '100.00'),
('2025-06-15', '4', '6', '6', '6', '0', '0', '0', '0', '6', '100.00'),
('2025-06-15', '5', '3', '3', '3', '0', '0', '0', '0', '3', '100.00'),
('2025-06-15', '9', '2', '2', '2', '0', '0', '0', '0', '2', '100.00'),
('2025-06-15', '10', '6', '6', '6', '0', '0', '0', '0', '6', '100.00'),
('2025-06-15', '11', '6', '6', '6', '0', '0', '0', '0', '6', '100.00'),
('2025-06-15', '12', '3', '3', '3', '0', '0', '0', '0', '3', '100.00'),
('2025-06-15', '18', '3', '3', '3', '0', '0', '3', '3', '0', '100.00'),
('2025-06-15', '19', '2', '2', '2', '0', '0', '0', '0', '2', '100.00'),
('2025-06-17', '18', '1', '1', '1', '0', '0', '0', '0', '1', '100.00'),
('2025-06-17', '19', '3', '3', '3', '0', '0', '0', '0', '3', '100.00'),
('2025-06-17', '20', '1', '1', '1', '0', '0', '0', '0', '1', '100.00');

-- Estructura de tabla `v_dispositivos_estado`
DROP TABLE IF EXISTS `v_dispositivos_estado`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_dispositivos_estado` AS select `d`.`id` AS `id`,`d`.`nombre` AS `nombre`,`d`.`ubicacion` AS `ubicacion`,`d`.`direccion_ip` AS `direccion_ip`,`d`.`direccion_mac` AS `direccion_mac`,`d`.`activo` AS `dispositivo_activo`,`r`.`temperatura` AS `temperatura`,`r`.`humedad` AS `humedad`,`r`.`ruido` AS `ruido`,`r`.`co2` AS `co2`,`r`.`lux` AS `lux`,`r`.`fecha_hora` AS `ultima_lectura`,`r`.`estado` AS `ultimo_estado`,case when `r`.`fecha_hora` > current_timestamp() - interval 1 hour then 'activo' when `r`.`fecha_hora` > current_timestamp() - interval 24 hour then 'inactivo_reciente' else 'inactivo' end AS `estado_conexion`,timestampdiff(MINUTE,`r`.`fecha_hora`,current_timestamp()) AS `minutos_desde_ultima_lectura` from (`dispositivos` `d` left join (select `registros`.`sensor_id` AS `sensor_id`,`registros`.`temperatura` AS `temperatura`,`registros`.`humedad` AS `humedad`,`registros`.`ruido` AS `ruido`,`registros`.`co2` AS `co2`,`registros`.`lux` AS `lux`,`registros`.`fecha_hora` AS `fecha_hora`,`registros`.`estado` AS `estado`,row_number() over ( partition by `registros`.`sensor_id` order by `registros`.`fecha_hora` desc) AS `rn` from `registros`) `r` on(`d`.`nombre` = `r`.`sensor_id` and `r`.`rn` = 1)) where `d`.`activo` = 1;

-- Datos de la tabla `v_dispositivos_estado`
INSERT INTO `v_dispositivos_estado` (`id`, `nombre`, `ubicacion`, `direccion_ip`, `direccion_mac`, `dispositivo_activo`, `temperatura`, `humedad`, `ruido`, `co2`, `lux`, `ultima_lectura`, `ultimo_estado`, `estado_conexion`, `minutos_desde_ultima_lectura`) VALUES
('6', 'Sensor-F702ECC5', 'Saala2', '192.168.1.79', '30:C6:F7:02:EC:C5', '1', '28.70', '64.10', '26.30', '402', '2466', '2025-06-17 20:29:53', 'alerta', 'inactivo_reciente', '856');

-- Estructura de tabla `v_estadisticas_diarias`
DROP TABLE IF EXISTS `v_estadisticas_diarias`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_estadisticas_diarias` AS select `registros`.`sensor_id` AS `sensor_id`,cast(`registros`.`fecha_hora` as date) AS `fecha`,count(0) AS `total_registros`,avg(`registros`.`temperatura`) AS `temp_promedio`,min(`registros`.`temperatura`) AS `temp_minima`,max(`registros`.`temperatura`) AS `temp_maxima`,avg(`registros`.`humedad`) AS `hum_promedio`,min(`registros`.`humedad`) AS `hum_minima`,max(`registros`.`humedad`) AS `hum_maxima`,avg(`registros`.`ruido`) AS `ruido_promedio`,min(`registros`.`ruido`) AS `ruido_minimo`,max(`registros`.`ruido`) AS `ruido_maximo`,avg(`registros`.`co2`) AS `co2_promedio`,min(`registros`.`co2`) AS `co2_minimo`,max(`registros`.`co2`) AS `co2_maximo`,avg(`registros`.`lux`) AS `lux_promedio`,min(`registros`.`lux`) AS `lux_minimo`,max(`registros`.`lux`) AS `lux_maximo`,sum(`registros`.`alerta_temperatura`) AS `alertas_temperatura`,sum(`registros`.`alerta_humedad`) AS `alertas_humedad`,sum(`registros`.`alerta_ruido`) AS `alertas_ruido`,sum(`registros`.`alerta_co2`) AS `alertas_co2`,sum(`registros`.`alerta_iluminacion`) AS `alertas_iluminacion`,sum(case when `registros`.`estado` = 'critico' then 1 else 0 end) AS `registros_criticos`,sum(case when `registros`.`estado` = 'alerta' then 1 else 0 end) AS `registros_alerta`,sum(case when `registros`.`estado` = 'normal' then 1 else 0 end) AS `registros_normales` from `registros` group by `registros`.`sensor_id`,cast(`registros`.`fecha_hora` as date);

-- Datos de la tabla `v_estadisticas_diarias`
INSERT INTO `v_estadisticas_diarias` (`sensor_id`, `fecha`, `total_registros`, `temp_promedio`, `temp_minima`, `temp_maxima`, `hum_promedio`, `hum_minima`, `hum_maxima`, `ruido_promedio`, `ruido_minimo`, `ruido_maximo`, `co2_promedio`, `co2_minimo`, `co2_maximo`, `lux_promedio`, `lux_minimo`, `lux_maximo`, `alertas_temperatura`, `alertas_humedad`, `alertas_ruido`, `alertas_co2`, `alertas_iluminacion`, `registros_criticos`, `registros_alerta`, `registros_normales`) VALUES
('Sensor-F702ECC5', '2025-06-15', '57', '29.142105', '28.50', '31.00', '62.082456', '57.40', '68.50', '31.001404', '19.35', '59.03', '325.3333', '73', '580', '655.5614', '1', '2466', '57', '57', '13', '0', '20', '22', '35', '0'),
('Sensor-F702ECC5', '2025-06-17', '5', '28.920000', '28.70', '29.30', '63.140000', '62.20', '64.10', '23.296000', '20.53', '26.30', '402.6000', '402', '404', '2602.6000', '2465', '2809', '5', '5', '0', '0', '0', '0', '5', '0');

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
