# Briefing Completo: Suite de Monitoreo Ambiental con Arduino

## 1. Introducción al Proyecto

### 1.1. Descripción General

El proyecto "Suite Ambiental" es un sistema completo de monitorización ambiental que integra dispositivos Arduino (ESP8266/ESP32) con una interfaz web para la visualización, gestión y análisis de datos ambientales. El sistema permite monitorizar en tiempo real variables como temperatura, humedad, nivel de ruido, CO2 y luminosidad desde múltiples dispositivos.

### 1.2. Objetivos del Sistema

- Recopilar datos ambientales desde dispositivos Arduino dispersos geográficamente
- Almacenar y procesar los datos en una base de datos centralizada
- Mostrar información en tiempo real mediante interfaz web responsive
- Generar informes y estadísticas sobre las variables ambientales
- Gestionar usuarios, dispositivos y configuraciones del sistema
- Facilitar la visualización pública de datos ambientales

### 1.3. Arquitectura General

La arquitectura del sistema sigue un modelo cliente-servidor con los siguientes componentes:

1. **Dispositivos Arduino**: Sensores que capturan datos ambientales
2. **API REST**: Endpoint para recepción de datos desde los dispositivos
3. **Base de Datos**: Almacenamiento MySQL/MariaDB con estructura optimizada
4. **Panel de Administración**: Interfaz web para gestión completa del sistema
5. **Visualizador Público**: Pantalla pública para mostrar datos en tiempo real
6. **Sistema de Backup**: Gestión de copias de seguridad del sistema completo

## 2. Entorno de Desarrollo

### 2.1. Requisitos Técnicos

#### Software Necesario
- Servidor web: Apache/Nginx con PHP 7.4 o superior
- Base de datos: MySQL 5.7+ o MariaDB 10.3+
- PHP con extensiones: PDO, PDO_MySQL, ZIP, JSON, mbstring
- Navegador web moderno con soporte JavaScript
- IDE Arduino para programación de dispositivos

#### Hardware Recomendado
- Servidor: CPU dual-core 2GHz+, 4GB RAM, 20GB espacio
- Dispositivos Arduino: ESP8266 o ESP32 con sensores ambientales
- Sensores: DHT22/DHT11 (temperatura/humedad), MQ-135 (CO2), BH1750 (luz), KY-038 (sonido)

### 2.2. Estructura de Directorios

```
/                   # Directorio raíz del proyecto
├── api/            # Endpoints para API REST
│   └── datos.php   # Receptor de datos de dispositivos Arduino
├── ArduinoSoft-Monitor/ # Visualizador público independiente
├── backups/        # Almacenamiento de backups generados
├── configbackup/   # Respaldos de archivos de configuración
├── documentos/     # Documentación del sistema
├── includes/       # Módulos y componentes del sistema
├── logs/           # Registros de actividad y errores
├── media/          # Archivos multimedia (logos, imágenes)
├── temp_backup/    # Directorio temporal para operaciones de backup
└── varios archivos PHP en la raíz para funciones principales
```

## 3. Base de Datos

### 3.1. Estructura de la Base de Datos

El sistema utiliza tres tablas principales:

#### Tabla: usuarios
```sql
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `contrasena` varchar(255) NOT NULL,
  `rol` enum('admin','operador') NOT NULL DEFAULT 'operador',
  `ultimo_acceso` datetime DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
```

#### Tabla: dispositivos
```sql
CREATE TABLE `dispositivos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `ubicacion` varchar(100) DEFAULT NULL,
  `fecha_registro` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ultima_conexion` datetime DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
```

#### Tabla: registros
```sql
CREATE TABLE `registros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sensor_id` varchar(50) NOT NULL,
  `fecha_hora` datetime NOT NULL,
  `temperatura` decimal(5,2) DEFAULT NULL,
  `humedad` decimal(5,2) DEFAULT NULL,
  `ruido` decimal(5,2) DEFAULT NULL,
  `co2` decimal(6,2) DEFAULT NULL,
  `luz` decimal(7,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sensor_fecha` (`sensor_id`, `fecha_hora`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
```

### 3.2. Relaciones entre Tablas

- La tabla `registros` se relaciona con `dispositivos` mediante el campo `sensor_id` que corresponde al campo `nombre` en la tabla dispositivos.
- Los usuarios de la tabla `usuarios` pueden acceder al sistema con diferentes permisos según su `rol`.

## 4. Flujo del Sistema

### 4.1. Inicialización del Sistema

1. Al acceder por primera vez, el sistema verifica la existencia del archivo `config.ini`
2. Si no existe, redirige a `configinicial.php` para configurar la conexión a la base de datos
3. El sistema crea automáticamente las tablas necesarias y un usuario administrador predeterminado
4. Se genera el archivo `config.ini` con la configuración básica del sistema

### 4.2. Recepción de Datos (API)

1. Los dispositivos Arduino envían datos a `api/datos.php` mediante solicitudes HTTP POST
2. La API verifica la validez de los datos JSON recibidos
3. Si el dispositivo no está registrado, se crea automáticamente en la tabla `dispositivos`
4. Los datos ambientales se insertan en la tabla `registros` con fecha y hora actuales
5. La API devuelve una respuesta JSON con confirmación o error

### 4.3. Panel de Administración

1. El usuario accede mediante `index.php` con sus credenciales
2. Tras la autenticación, es redirigido a `panel.php` con permisos según su rol
3. El panel muestra estadísticas generales y permite navegar a las diferentes secciones
4. Las secciones se cargan dinámicamente desde los archivos en la carpeta `includes`

### 4.4. Visualización Pública

1. El monitor público (`public.php`) muestra datos en tiempo real para pantallas informativas
2. Los datos se actualizan automáticamente según el intervalo configurado en `config.ini`
3. El diseño se adapta al tipo de pantalla y distancia de visualización configurados

## 5. Componentes Principales

### 5.1. Sistema de Autenticación

- Autenticación basada en usuario/contraseña almacenados en base de datos
- Roles diferenciados: administrador y operador
- Sesiones PHP para mantener estado de autenticación
- Cierre de sesión seguro mediante `logout.php`

### 5.2. Gestión de Dispositivos

El módulo `includes/dispositivos.php` gestiona:
- Listado de dispositivos con estado en tiempo real
- Visualización de última conexión y datos recientes
- Edición de información del dispositivo (principalmente ubicación)
- Monitoreo de sensores específicos por dispositivo

### 5.3. Dashboard Principal

El archivo `includes/dashboard.php` implementa:
- Resumen estadístico del sistema (dispositivos, usuarios, registros)
- Tarjetas informativas para acceso rápido a funcionalidades
- Visualización de dispositivos activos/inactivos
- Alertas sobre valores fuera de rango configurado

### 5.4. Configuración del Sistema

El archivo `includes/configuracion.php` permite:
- Edición de parámetros de configuración general
- Gestión de umbrales ambientales para alertas
- Configuración del monitor público
- Administración del sistema de copias de seguridad

### 5.5. Sistema de Informes

- Generación de informes estadísticos sobre variables ambientales
- Gráficos y tablas para visualización de tendencias
- Exportación de datos en formatos CSV/PDF
- Filtros por fecha, dispositivo y tipo de variable

### 5.6. Sistema de Backup

El sistema implementa un gestor de backup completo (`includes/backup_manager.php`) con:
- Copias de seguridad del proyecto completo
- Exportación de base de datos
- Backups incrementales de la configuración
- Sistema de restauración con validación

## 6. Guía de Implementación (Paso a Paso)

### 6.1. Configuración del Entorno

1. **Instalar requisitos previos:**
   ```bash
   # En sistemas basados en Debian/Ubuntu
   sudo apt update
   sudo apt install apache2 mariadb-server php php-mysql php-zip php-mbstring php-json
   
   # En XAMPP/WAMP ya vienen incluidos estos componentes
   ```

2. **Configurar virtualhost en Apache:**
   ```apache
   <VirtualHost *:80>
       DocumentRoot "/ruta/al/proyecto"
       ServerName ambiental.local
       <Directory "/ruta/al/proyecto">
           AllowOverride All
           Require all granted
       </Directory>
   </VirtualHost>
   ```

3. **Crear base de datos vacía:**
   ```sql
   CREATE DATABASE suite_ambiental CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci;
   CREATE USER 'ambiental_user'@'localhost' IDENTIFIED BY 'contraseña_segura';
   GRANT ALL PRIVILEGES ON suite_ambiental.* TO 'ambiental_user'@'localhost';
   FLUSH PRIVILEGES;
   ```

### 6.2. Instalación del Sistema

1. **Copiar archivos del proyecto** a la raíz del servidor web

2. **Crear estructura de directorios:**
   ```bash
   mkdir -p backups configbackup logs media temp_backup
   chmod 755 backups configbackup logs media temp_backup
   touch logs/access.log logs/backup_operations.log logs/cambios.log
   chmod 666 logs/access.log logs/backup_operations.log logs/cambios.log
   ```

3. **Acceder al sistema** por primera vez mediante el navegador:
   - El sistema detectará que no existe configuración y redirigirá a `configinicial.php`
   - Ingresar los datos de conexión a la base de datos creada anteriormente
   - El sistema creará automáticamente las tablas y un usuario administrador

4. **Iniciar sesión** con las credenciales predeterminadas:
   - Usuario: `admin`
   - Contraseña: `admin123`
   - **Importante:** Cambiar esta contraseña inmediatamente desde el panel de usuarios

### 6.3. Configuración Inicial del Sistema

1. **Configuración general:**
   - Acceder a la sección "Configuración" en el panel
   - Establecer nombre del sistema, zona horaria y parámetros generales

2. **Umbrales ambientales:**
   - Configurar valores máximos/mínimos para cada variable ambiental
   - Estos valores se usarán para generar alertas cuando se superen los límites

3. **Configuración del monitor público:**
   - Establecer intervalo de actualización
   - Configurar modo de visualización según tipo de pantalla

### 6.4. Programación de Dispositivos Arduino

1. **Instalar librerías necesarias** en el IDE Arduino:
   - ArduinoJson (para manejo de JSON)
   - ESP8266WiFi o WiFi (para ESP32)
   - HTTPClient
   - Librerías específicas para cada sensor (DHT, BH1750, etc.)

2. **Código base para dispositivos Arduino** (ESP8266/ESP32):

```cpp
#include <ESP8266WiFi.h>  // Usar <WiFi.h> para ESP32
#include <ESP8266HTTPClient.h>  // Usar <HTTPClient.h> para ESP32
#include <ArduinoJson.h>
#include "DHT.h"
#include <BH1750.h>

// Configuración de WiFi y servidor
const char* ssid = "NOMBRE_WIFI";
const char* password = "PASSWORD_WIFI";
const char* serverUrl = "http://tu-servidor.com/api/datos.php";
const char* deviceName = "arduino01";  // Nombre único para identificar el dispositivo

// Configuración de pines y sensores
#define DHTPIN 2
#define DHTTYPE DHT22
#define NOISE_PIN A0
#define CO2_PIN A1

// Inicialización de sensores
DHT dht(DHTPIN, DHTTYPE);
BH1750 lightMeter;

void setup() {
  Serial.begin(115200);
  
  // Iniciar sensores
  dht.begin();
  Wire.begin();
  lightMeter.begin();
  
  // Conectar a WiFi
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("WiFi conectado");
}

void loop() {
  if (WiFi.status() == WL_CONNECTED) {
    // Leer sensores
    float temperatura = dht.readTemperature();
    float humedad = dht.readHumidity();
    float ruido = analogRead(NOISE_PIN) / 10.0;  // Simplificado, ajustar según sensor
    float co2 = analogRead(CO2_PIN) * 2;  // Simplificado, ajustar según sensor
    float luz = lightMeter.readLightLevel();
    
    // Verificar lecturas válidas
    if (isnan(temperatura) || isnan(humedad)) {
      Serial.println("Error leyendo sensor DHT");
      delay(2000);
      return;
    }
    
    // Preparar JSON
    StaticJsonDocument<200> doc;
    doc["nombre"] = deviceName;
    doc["temperatura"] = temperatura;
    doc["humedad"] = humedad;
    doc["ruido"] = ruido;
    doc["co2"] = co2;
    doc["luz"] = luz;
    
    String jsonData;
    serializeJson(doc, jsonData);
    
    // Enviar datos al servidor
    WiFiClient client;
    HTTPClient http;
    http.begin(client, serverUrl);
    http.addHeader("Content-Type", "application/json");
    
    int httpResponseCode = http.POST(jsonData);
    if (httpResponseCode > 0) {
      String response = http.getString();
      Serial.println("Respuesta: " + response);
    } else {
      Serial.println("Error en la solicitud HTTP: " + String(httpResponseCode));
    }
    
    http.end();
  }
  
  // Esperar antes de la próxima lectura
  delay(60000);  // 1 minuto
}
```

3. **Adaptar el código** según los sensores específicos disponibles
4. **Configurar la dirección del servidor** en cada dispositivo

## 7. Mantenimiento del Sistema

### 7.1. Backups Recomendados

- **Backups de configuración:** Diarios (automáticos)
- **Backups completos:** Semanales (configurables desde el panel)
- **Backups de base de datos:** Diarios o según volumen de datos

### 7.2. Monitorización del Sistema

1. **Logs del sistema:**
   - `access.log`: Registra accesos al sistema
   - `backup_operations.log`: Operaciones de backup
   - `cambios.log`: Modificaciones en la configuración

2. **Verificación periódica:**
   - Comprobar regularmente el espacio en disco
   - Monitorizar el rendimiento de la base de datos
   - Verificar conectividad de los dispositivos Arduino

### 7.3. Actualización del Sistema

Para actualizaciones futuras del sistema:

1. Realizar una copia de seguridad completa
2. Seguir las instrucciones específicas de la actualización
3. Verificar la compatibilidad con los dispositivos existentes
4. Probar el sistema en un entorno de staging antes de producción

## 8. Estructura y Descripción de Archivos

### 8.1. Archivos Principales (Raíz)

| Archivo | Descripción |
|---------|-------------|
| `index.php` | Página de inicio de sesión |
| `panel.php` | Panel de administración principal |
| `public.php` | Visualizador público para pantallas |
| `config.ini` | Configuración central del sistema |
| `configinicial.php` | Asistente de configuración inicial |
| `logout.php` | Cierre de sesión seguro |
| `callback.php` | Procesamiento de respuestas de autenticación |

### 8.2. Directorio API

| Archivo | Descripción |
|---------|-------------|
| `datos.php` | Endpoint principal para recepción de datos Arduino |
| `.htaccess` | Configuración de seguridad para la API |

### 8.3. Directorio Includes

| Archivo | Descripción |
|---------|-------------|
| `configuracion.php` | Gestión de configuración del sistema |
| `dashboard.php` | Panel principal con estadísticas |
| `dispositivos.php` | Gestión de dispositivos conectados |
| `usuarios.php` | Administración de usuarios del sistema |
| `informes.php` | Generación de informes estadísticos |
| `backup_manager.php` | Gestor de copias de seguridad |
| `backup_operations.php` | Funciones auxiliares para backups |
| `database_manager.php` | Gestión centralizada de base de datos |
| `timezone_manager.php` | Gestión de zona horaria del sistema |

## 9. Configuraciones Avanzadas

### 9.1. Optimización de Base de Datos

Para sistemas con gran volumen de datos:

```sql
-- Índices adicionales para optimizar consultas frecuentes
ALTER TABLE registros ADD INDEX idx_fecha (fecha_hora);
ALTER TABLE registros ADD INDEX idx_temperatura (temperatura);
ALTER TABLE registros ADD INDEX idx_humedad (humedad);

-- Particionamiento por rango de fechas para tablas grandes
ALTER TABLE registros PARTITION BY RANGE (TO_DAYS(fecha_hora)) (
    PARTITION p_2023_01 VALUES LESS THAN (TO_DAYS('2023-02-01')),
    PARTITION p_2023_02 VALUES LESS THAN (TO_DAYS('2023-03-01')),
    -- Continuar según necesidad...
    PARTITION p_future VALUES LESS THAN MAXVALUE
);
```

### 9.2. Seguridad Adicional

1. **Protección del directorio API:**
   ```apache
   # Incluir en .htaccess de API
   <IfModule mod_rewrite.c>
     RewriteEngine On
     # Solo permitir solicitudes POST a datos.php
     RewriteCond %{REQUEST_METHOD} !^POST$
     RewriteRule ^datos\.php - [F]
   </IfModule>
   ```

2. **Protección contra inyección SQL:**
   - El sistema ya utiliza PDO con prepared statements
   - Mantener actualizadas las librerías de seguridad

3. **Validación de datos:**
   - Implementar validación más estricta de datos recibidos por API
   - Limitar tasa de solicitudes por IP para prevenir abusos

### 9.3. Escalabilidad

Para sistemas con muchos dispositivos:

1. **Implementar colas de mensajes** para procesar datos asíncronamente
2. **Considerar bases de datos de series temporales** (InfluxDB, TimescaleDB)
3. **Implementar cachés** para consultas frecuentes (Redis, Memcached)

## 10. Resolución de Problemas Comunes

### 10.1. Problemas de Conexión con Dispositivos

1. **Verificar conectividad WiFi** del dispositivo Arduino
2. **Comprobar accesibilidad del servidor** desde la red del dispositivo
3. **Revisar logs de API** para errores en recepción de datos
4. **Verificar formato correcto de JSON** enviado por el dispositivo

### 10.2. Problemas de Rendimiento

1. **Optimizar consultas a base de datos:**
   - Revisar índices existentes
   - Implementar cachés para consultas frecuentes

2. **Mejorar rendimiento de PHP:**
   - Activar opcode caching (OPcache)
   - Implementar sistema de caché para páginas frecuentes

3. **Limpiar registros antiguos:**
   - Implementar política de retención de datos
   - Archivar datos históricos que no se consulten frecuentemente

### 10.3. Problemas de Espacio en Disco

1. **Gestionar backups antiguos:**
   - Implementar rotación automática de backups
   - Considerar almacenamiento externo para backups históricos

2. **Optimizar almacenamiento de logs:**
   - Configurar rotación de logs
   - Comprimir logs antiguos

## 11. Conclusiones y Recomendaciones

### 11.1. Mejores Prácticas

1. **Cambiar credenciales predeterminadas** inmediatamente después de la instalación
2. **Realizar backups regularmente** y verificar su integridad
3. **Monitorizar el sistema** para detectar problemas potenciales
4. **Mantener actualizados** todos los componentes del sistema

### 11.2. Evolución Futura

El sistema puede expandirse con:

1. **Aplicación móvil** para monitoreo remoto
2. **Integración con sistemas domóticos** (HomeAssistant, OpenHAB)
3. **Implementación de machine learning** para predicción de tendencias ambientales
4. **Integración con servicios en la nube** para análisis avanzados

---

## Anexo I: Diagrama de Arquitectura del Sistema

```
┌─────────────┐     ┌──────────────┐     ┌─────────────┐
│ Dispositivo │     │ Dispositivo  │     │ Dispositivo │
│  Arduino 1  │     │  Arduino 2   │     │  Arduino N  │
└──────┬──────┘     └───────┬──────┘     └──────┬──────┘
       │                    │                   │
       │                    │                   │
       │                    ▼                   │
       │            ┌───────────────┐           │
       └───────────►│  API REST     │◄──────────┘
                    │ (datos.php)   │
                    └───────┬───────┘
                            │
                            ▼
                    ┌───────────────┐
                    │   Base de     │
                    │    Datos      │
                    └───────┬───────┘
                            │
                ┌───────────┴───────────┐
                │                       │
                ▼                       ▼
        ┌───────────────┐       ┌───────────────┐
        │ Panel Admin   │       │  Monitor      │
        │ (panel.php)   │       │  Público      │
        └───────────────┘       └───────────────┘
```

## Anexo II: Ejemplo de Configuración (config.ini)

```ini
; Configuración del Sistema de Monitoreo Ambiental
; Generado automáticamente el 2025-06-11 16:24:20

[database]
host = "localhost"
port = 3306
user = "ambiental_user"
password = "password_seguro"
database = "suite_ambiental"
charset = "utf8mb4"
timezone = "+02:00"

[sistema]
nombre = "Suite Ambiental"
version = "2.0"
timezone = "+02:00"
log_level = "info"

[referencias]
temperatura_max = 25
humedad_max = 48
ruido_max = 35
co2_max = 1000
lux_min = 195

[publico]
; Configuración específica para el monitor público
refresh_interval = 60
display_mode = "fullscreen"
distance_optimization = "2m"
screen_ratio = "16:9"
```

---

Documento generado por el equipo de ArduinoSoft Ambiental. Para más información y soporte, contacte con el administrador del sistema.
