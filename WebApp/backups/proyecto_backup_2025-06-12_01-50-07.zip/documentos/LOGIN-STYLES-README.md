# Organización de Estilos para Páginas de Login

## Resumen

Este documento describe la organización y separación de estilos CSS para las páginas de login (`index.php`) y bienvenida (`callback.php`) del Sistema de Monitoreo Ambiental ArduinoSoft.

## Estructura de Archivos

- `styles.css`: Estilos generales del sistema (usado por todas las páginas)
- `login-pages.css`: Estilos específicos para páginas de login y bienvenida

## Separación de Estilos

### 1. Clases Específicas
Se utilizan clases específicas para cada página:
- `index-page`: Clase específica para página de login con diseño horizontal
- `callback-page`: Clase específica para página de bienvenida con diseño vertical

```html
<!-- En index.php -->
<body class="login-body index-page">

<!-- En callback.php -->
<body class="login-body callback-page">
```

### 2. Organización del CSS
El archivo `login-pages.css` está organizado en tres secciones:

#### 2.1. Estilos Base Compartidos
- Variables CSS comunes
- Fondo y animaciones
- Estructura base de tarjetas
- Componentes comunes (logos, alertas)

#### 2.2. Estilos para Index.php (Horizontal)
- Layout con grid de 2 columnas
- Divisor vertical
- Responsividad específica

#### 2.3. Estilos para Callback.php (Vertical)
- Layout con flexbox vertical
- Componentes de countdown
- Animaciones específicas
- Responsividad específica

## Diferencias de Diseño

### Index.php (Login)
- Diseño horizontal con dos columnas
- Izquierda: Logo e información
- Derecha: Formulario de acceso
- En pantallas pequeñas se convierte a vertical

### Callback.php (Bienvenida)
- Diseño vertical centrado
- Logo y título en la parte superior
- Mensaje de bienvenida
- Contador regresivo con animaciones
- Botón de acción para acceso inmediato

## Mantenimiento

Al hacer modificaciones:
1. Para cambios globales: editar `styles.css`
2. Para cambios específicos de login/bienvenida: editar `login-pages.css`
3. Usar los selectores específicos (`.login-body.index-page` o `.login-body.callback-page`)

## Ventajas de esta Estructura

1. **Claridad**: Separación clara de estilos por página
2. **Especificidad**: Evita conflictos entre diferentes diseños
3. **Mantenibilidad**: Facilita encontrar y modificar estilos específicos
4. **Reutilización**: Comparte componentes comunes cuando es posible
