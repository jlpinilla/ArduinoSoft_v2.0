<?php
// ===== DASHBOARD PRINCIPAL DEL SISTEMA DE MONITOREO AMBIENTAL =====
/**
 * INCLUDES/DASHBOARD.PHP - Panel Principal del Dashboard
 * 
 * Este archivo contiene la página principal del dashboard que muestra:
 * - Estadísticas generales del sistema
 * - Tarjetas informativas de funcionalidades
 * - Información del usuario actual
 * - Alertas recientes del sistema
 * 
 * Funcionalidades principales:
 * - Conteo de dispositivos, usuarios y registros
 * - Estado de dispositivos activos en tiempo real
 * - Enlaces de navegación a todas las secciones
 * - Monitoreo de alertas por valores fuera de rango
 */

// ===== OBTENCIÓN DE ESTADÍSTICAS DEL SISTEMA OPTIMIZADA =====
try {
    // Incluir gestor optimizado de base de datos
    require_once __DIR__ . '/database_manager.php';
    
    // Obtener instancia del gestor de base de datos optimizado
    $db_manager = getDBManager($config);
    
    // === Consulta optimizada única para obtener todas las estadísticas ===
    // Una sola consulta para reducir el overhead de múltiples consultas
    $stats_query = "
        SELECT 
            (SELECT COUNT(*) FROM dispositivos) as total_dispositivos,
            (SELECT COUNT(*) FROM usuarios) as total_usuarios,
            (SELECT COUNT(DISTINCT d.id) 
             FROM dispositivos d 
             INNER JOIN registros r ON d.nombre = r.sensor_id 
             WHERE r.fecha_hora >= DATE_SUB(NOW(), INTERVAL 1 HOUR)) as dispositivos_activos,
            (SELECT COUNT(*) 
             FROM registros 
             WHERE DATE(fecha_hora) = CURDATE()) as registros_hoy,
            (SELECT COUNT(*) 
             FROM registros 
             WHERE fecha_hora >= DATE_SUB(NOW(), INTERVAL 7 DAY)) as registros_semana
    ";
      // Ejecutar consulta optimizada
    $stats = $db_manager->fetchRow($stats_query, []);
    
    // Asignar variables para compatibilidad con código existente
    $total_dispositivos = $stats['total_dispositivos'] ?? 0;
    $total_usuarios = $stats['total_usuarios'] ?? 0;
    $dispositivos_activos = $stats['dispositivos_activos'] ?? 0;
    $registros_hoy = $stats['registros_hoy'] ?? 0;
    $registros_semana = $stats['registros_semana'] ?? 0;
    
} catch (Exception $e) {
    // === Manejo robusto de errores con logging ===
    $error_message = "Error al cargar estadísticas: " . $e->getMessage();
    error_log("Dashboard Stats Error: " . $e->getMessage());
    
    // Valores por defecto en caso de error
    $total_dispositivos = 0;
    $total_usuarios = 0;
    $dispositivos_activos = 0;
    $registros_hoy = 0;
    $registros_semana = 0;
}

// Obtener información del sistema desde configuración
$sistema_nombre = $config['sistema']['nombre'] ?? 'Sistema de Monitoreo Ambiental';
$sistema_version = $config['sistema']['version'] ?? '';
?>


<!-- ===== ENCABEZADO DE LA PÁGINA PRINCIPAL ===== -->
<h2 class="page-title">🎛️ Panel de Control - <?php echo htmlspecialchars($sistema_nombre); ?></h2>
<p class="subtitle"><?php echo htmlspecialchars($sistema_nombre); ?> • Versión <?php echo htmlspecialchars($sistema_version); ?> • 

<?php if (isset($error_message)): ?>
    <!-- Mensaje de error si falla la conexión a BD -->
    <div class="alert alert-error"><?php echo htmlspecialchars($error_message); ?></div>
<?php endif; ?>

<!-- ===== BANNER DE ESTADÍSTICAS RÁPIDAS ===== -->
<!-- Muestra resumen ejecutivo del estado del sistema -->
<div class="stats-banner">
    📊 Estado del Sistema - 
    Dispositivos: <strong><?php echo $total_dispositivos; ?></strong> | 
    Activos Ahora: <strong style="color: var(--success-color);"><?php echo $dispositivos_activos; ?></strong> | 
    Usuarios: <strong><?php echo $total_usuarios; ?></strong> | 
    Registros Hoy: <strong><?php echo number_format($registros_hoy); ?></strong> |
    Esta Semana: <strong><?php echo number_format($registros_semana); ?></strong>
</div>

<!-- ===== TARJETAS DE FUNCIONALIDADES PRINCIPALES ===== -->
<!-- Grid de tarjetas navegables con información detallada de cada módulo -->
<div class="menu-grid">
    
    <!-- === TARJETA: GESTIÓN DE USUARIOS === -->
    <div class="menu-card" onclick="location.href='?seccion=usuarios'">
        <h3>👥 Gestionar Usuarios</h3>
        <p>Administre los usuarios del sistema: crear, editar, eliminar y gestionar roles de acceso.</p>
        <div class="info-box">
            <strong>Funcionalidades:</strong>
            <ul style="text-align: left; margin-top: 10px;">
                <li>Crear nuevos usuarios</li>
                <li>Editar información existente</li>
                <li>Eliminar usuarios</li>
                <li>Buscar por nombre o rol</li>
                <li>Gestión de roles (admin/operador)</li>
            </ul>
        </div>
        <?php if ($rol !== 'admin'): ?>
        <!-- Restricción de acceso para usuarios no administradores -->
        <div class="alert alert-error" style="margin-top: 10px;">
            <small>⚠️ Requiere permisos de administrador</small>
        </div>
        <?php endif; ?>
    </div>
      <!-- === TARJETA: GESTIÓN DE DISPOSITIVOS === -->
    <div class="menu-card" onclick="location.href='?seccion=dispositivos'">
        <h3>📡 Gestionar Dispositivos</h3>
        <p>Visualice y administre todos los sensores ambientales conectados al sistema en tiempo real.</p>
        <div class="info-box">
            <strong>Funcionalidades Avanzadas:</strong>
            <ul style="text-align: left; margin-top: 10px;">
                <li>Lista completa con estado en vivo</li>
                <li>Monitorización individual detallada</li>
                <li>Estadísticas por dispositivo (24h)</li>
                <li>Edición de ubicación y configuración</li>
                <li>Detección automática de inactividad</li>
                <li>Alertas visuales por umbrales</li>
                <li>Información de red (IP/MAC)</li>
            </ul>
        </div>
        <!-- Indicador de estado de dispositivos -->
        <div class="stats-banner" style="margin-top: 10px;">
            <?php echo $dispositivos_activos; ?> de <?php echo $total_dispositivos; ?> dispositivos activos ahora
        </div>
    </div>
    
    <!-- === TARJETA: MONITOR PÚBLICO === -->
    <div class="menu-card" onclick="goToPublicMonitor()">
        <h3>🖥️ Monitor Público</h3>
        <p>Pantalla de visualización pública optimizada para monitores grandes y accesibilidad completa.</p>
        <div class="info-box">
            <strong>Características Mejoradas:</strong>
            <ul style="text-align: left; margin-top: 10px;">
                <li>Visualización en tiempo real (60s)</li>
                <li>Diseño responsive 100% accesible</li>
                <li>Navegación por teclado completa</li>
                <li>Indicadores visuales de estado</li>
                <li>Modo oscuro/claro automático</li>
                <li>Compatibilidad con lectores de pantalla</li>
                <li>No requiere autenticación</li>
            </ul>
        </div>
        <!-- Indicador de acceso público -->
        <div class="alert alert-success" style="margin-top: 10px;">
            <small>✅ Acceso público optimizado y accesible</small>
        </div>
    </div>
      <!-- === TARJETA: INFORMES Y ESTADÍSTICAS === -->
    <div class="menu-card" onclick="location.href='?seccion=informes'">
        <h3>📈 Informes y Estadísticas</h3>
        <p>Genere reportes detallados y estadísticas avanzadas del sistema de monitoreo ambiental.</p>
        <div class="info-box">
            <strong>Funcionalidades Completas:</strong>
            <ul style="text-align: left; margin-top: 10px;">
                <li>Resumen ejecutivo de dispositivos</li>
                <li>Estadísticas en tiempo real</li>
                <li>Gráfico de tendencias por hora</li>
                <li>Exportación CSV funcional</li>
                <li>Filtros avanzados por fecha/dispositivo</li>
                <li>Ranking de dispositivos más activos</li>
                <li>Detección automática de alertas</li>
            </ul>
        </div>
        <!-- Contador de registros procesados -->
        <div class="stats-banner" style="margin-top: 10px;">
            <?php echo number_format($registros_hoy); ?> registros procesados hoy
        </div>
    </div>
    
    <?php if ($rol === 'admin'): ?>
    <!-- === TARJETA: CONFIGURACIÓN DEL SISTEMA === -->
    <div class="menu-card" onclick="location.href='?seccion=configuracion'">
        <h3>⚙️ Configuración del Sistema</h3>
        <p>Configure todos los parámetros del sistema, integraciones y umbrales de alerta.</p>
        <div class="info-box">
            <strong>Opciones Avanzadas:</strong>
            <ul style="text-align: left; margin-top: 10px;">
                <li>Umbrales de alerta personalizables</li>
                <li>Configuración de base de datos</li>
                <li>Integración Azure/Teams completa</li>
                <li>Gestión de logos del sistema</li>
                <li>Monitor público personalizable</li>
                <li>Backups automáticos de configuración</li>
                <li>Prueba de conectividad Teams</li>
            </ul>
        </div>
        <!-- Indicador de estado de configuración -->
        <div class="alert alert-info" style="margin-top: 10px;">
            <small>🔧 Configuración avanzada disponible</small>
        </div>
    </div>
    
    <!-- === TARJETA: SISTEMA DE BACKUPS === -->
    <div class="menu-card" onclick="location.href='?seccion=backups'">
        <h3>💾 Sistema de Backups</h3>
        <p>Gestión completa de copias de seguridad del proyecto y base de datos.</p>
        <div class="info-box">
            <strong>Tipos de Backup:</strong>
            <ul style="text-align: left; margin-top: 10px;">
                <li>Backup completo del proyecto</li>
                <li>Backup de base de datos (SQL)</li>
                <li>Backup combinado (proyecto + BD)</li>
                <li>Descarga directa de archivos ZIP</li>
                <li>Gestión de archivos existentes</li>
                <li>Logs detallados de operaciones</li>
                <li>Compatible con Windows/Linux</li>
            </ul>
        </div>
        <!-- Indicador de backups disponibles -->
        <div class="stats-banner" style="margin-top: 10px;">
            Sistema de respaldo completo operativo
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- ===== INFORMACIÓN DEL SISTEMA Y USUARIO ACTUAL ===== -->
<!-- Panel informativo con datos de sesión y configuración -->
<div class="system-info">
    <h3>Información del Sistema</h3>
    <div class="system-info-content">
        <!-- Usuario autenticado actualmente -->
        <div class="system-info-item">
            <span class="system-info-label">Usuario Actual:</span>
            <span><?php echo htmlspecialchars($usuario); ?></span>
        </div>
        <!-- Rol del usuario (admin/operador) -->
        <div class="system-info-item">
            <span class="system-info-label">Rol:</span>
            <span><?php echo htmlspecialchars(ucfirst($rol)); ?></span>
        </div>
        <!-- Timestamp de la sesión actual -->
        <div class="system-info-item">
            <span class="system-info-label">Última Conexión:</span>
            <span><?php echo date('d/m/Y H:i:s'); ?></span>
        </div>
        <!-- Base de datos suite_ambiental en uso -->
        <div class="system-info-item">
            <span class="system-info-label">Base de Datos:</span>
            <span><?php echo htmlspecialchars($config['database']['database']); ?></span>
        </div>        <!-- Información de versión del sistema -->
        <div class="system-info-item">
            <span class="system-info-label">Versión:</span>
            <span><?php echo htmlspecialchars($sistema_nombre); ?> v<?php echo htmlspecialchars($sistema_version); ?> - Edición Completa</span>
        </div>
        <!-- Estado de las funcionalidades -->
        <div class="system-info-item">
            <span class="system-info-label">Estado:</span>
            <span style="color: var(--success-color); font-weight: 600;">✅ Totalmente Operativo</span>
        </div>
        <!-- Funcionalidades implementadas -->
        <div class="system-info-item">
            <span class="system-info-label">Módulos Activos:</span>
            <span>Monitoreo • Informes • Backups • Configuración • Teams</span>
        </div>
    </div>
</div>

<!-- ===== SISTEMA DE ALERTAS RECIENTES ===== -->
<!-- Monitoreo de valores fuera de rango en las últimas 2 horas -->
<?php
try {
    // === Consulta de registros con valores de alerta ===
    // Busca registros que excedan los límites configurados en config.ini
    $alertas_query = "
        SELECT r.*, d.nombre as dispositivo_nombre 
        FROM registros r 
        INNER JOIN dispositivos d ON r.sensor_id = d.nombre 
        WHERE r.fecha_hora >= DATE_SUB(NOW(), INTERVAL 2 HOUR)
        AND (
            r.temperatura > {$config['referencias']['temperatura_max']} OR 
            r.humedad > {$config['referencias']['humedad_max']} OR 
            r.ruido > {$config['referencias']['ruido_max']} OR 
            r.co2 > {$config['referencias']['co2_max']} OR 
            r.lux < {$config['referencias']['lux_min']}        )
        ORDER BY r.fecha_hora DESC 
        LIMIT 5
    ";
    $alertas = $db_manager->query($alertas_query, []);
    
    // === Renderizado de alertas si existen ===
    if (count($alertas) > 0):
?>
<div class="alert alert-error" style="margin-top: 24px;">
    <h3>⚠️ Alertas Recientes (Últimas 2 horas)</h3>
    <div style="margin-top: 12px;">
        <?php foreach ($alertas as $alerta): ?>
            <div style="border-left: 3px solid var(--error-color); padding-left: 12px; margin-bottom: 8px;">
                <!-- Información del dispositivo y timestamp -->
                <strong><?php echo htmlspecialchars($alerta['dispositivo_nombre']); ?></strong> - 
                <?php echo date('d/m/Y H:i', strtotime($alerta['fecha_hora'])); ?>
                <br>
                <small>
                    <!-- Indicadores específicos por tipo de sensor fuera de rango -->
                    <?php if ($alerta['temperatura'] > $config['referencias']['temperatura_max']): ?>
                        🌡️ Temperatura: <?php echo $alerta['temperatura']; ?>°C 
                    <?php endif; ?>
                    <?php if ($alerta['humedad'] > $config['referencias']['humedad_max']): ?>
                        💧 Humedad: <?php echo $alerta['humedad']; ?>% 
                    <?php endif; ?>
                    <?php if ($alerta['ruido'] > $config['referencias']['ruido_max']): ?>
                        🔊 Ruido: <?php echo $alerta['ruido']; ?>dB 
                    <?php endif; ?>
                    <?php if ($alerta['co2'] > $config['referencias']['co2_max']): ?>
                        ☁️ CO2: <?php echo $alerta['co2']; ?>ppm 
                    <?php endif; ?>
                    <?php if ($alerta['lux'] < $config['referencias']['lux_min']): ?>
                        💡 Luz: <?php echo $alerta['lux']; ?>lux 
                    <?php endif; ?>
                </small>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php    endif;
} catch (Exception $e) {
    // === Manejo silencioso de errores en alertas ===
    // No interrumpe la carga del dashboard si falla el sistema de alertas
}
?>

<!-- ===== SECCIÓN DE ACTUALIZACIONES RECIENTES ===== -->
<div class="system-updates" style="margin-top: 24px;">
    <h3>🆕 Últimas Actualizaciones del Sistema</h3>
    <div class="updates-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-top: 15px;">
        
        <!-- Actualización: Sistema de Backups -->
        <div class="update-card" style="background: var(--card-background); padding: 20px; border-radius: 10px; border-left: 4px solid var(--success-color);">
            <h4 style="margin: 0 0 10px 0; color: var(--success-color);">💾 Sistema de Backups Completo</h4>
            <p style="margin: 0; font-size: 0.9em; color: var(--text-light);">
                Implementado sistema integral de copias de seguridad con descarga directa, 
                compatible con Windows y Linux. Incluye backup de proyecto, base de datos y configuraciones.
            </p>
            <small style="color: var(--text-light); font-style: italic;">✅ Completamente funcional</small>
        </div>
        
        <!-- Actualización: Informes Mejorados -->
        <div class="update-card" style="background: var(--card-background); padding: 20px; border-radius: 10px; border-left: 4px solid var(--primary-color);">
            <h4 style="margin: 0 0 10px 0; color: var(--primary-color);">📈 Informes y Estadísticas</h4>
            <p style="margin: 0; font-size: 0.9em; color: var(--text-light);">
                Exportación CSV funcional, gráficos de tendencias interactivos, 
                filtros avanzados y ranking de dispositivos más activos.
            </p>
            <small style="color: var(--text-light); font-style: italic;">✅ Exportación CSV • Gráficos • Filtros</small>
        </div>
        
        <!-- Actualización: Monitor Público Accesible -->
        <div class="update-card" style="background: var(--card-background); padding: 20px; border-radius: 10px; border-left: 4px solid var(--warning-color);">
            <h4 style="margin: 0 0 10px 0; color: var(--warning-color);">🖥️ Monitor Público Mejorado</h4>
            <p style="margin: 0; font-size: 0.9em; color: var(--text-light);">
                Totalmente accesible con navegación por teclado, compatible con lectores de pantalla 
                y diseño responsive optimizado para todos los dispositivos.
            </p>
            <small style="color: var(--text-light); font-style: italic;">✅ 100% Accesible • Responsive • WCAG</small>
        </div>
        
        <?php if ($rol === 'admin'): ?>
        <!-- Actualización: Configuración Avanzada -->
        <div class="update-card" style="background: var(--card-background); padding: 20px; border-radius: 10px; border-left: 4px solid var(--info-color);">
            <h4 style="margin: 0 0 10px 0; color: var(--info-color);">⚙️ Configuración Avanzada</h4>
            <p style="margin: 0; font-size: 0.9em; color: var(--text-light);">
                Integración completa con Microsoft Teams, gestión de logos, 
                backups automáticos de configuración y pruebas de conectividad.
            </p>
            <small style="color: var(--text-light); font-style: italic;">✅ Teams • Logos • Backups Config</small>
        </div>
        <?php endif; ?>
        
    </div>
</div>
