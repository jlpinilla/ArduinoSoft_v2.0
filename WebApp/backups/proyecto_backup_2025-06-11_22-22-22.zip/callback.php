<?php
/**
 * CALLBACK.PHP - Página de Bienvenida Post-Login
 * Sistema de Monitoreo Ambiental ArduinoSoft
 * 
 * Funcionalidad:
 * - Mostrar mensaje de bienvenida personalizado tras login exitoso
 * - Contador regresivo de 5 segundos con JavaScript
 * - Redirección automática a panel.php (panel principal)
 * - Mostrar información básica del usuario autenticado
 * - Página de transición amigable entre login y panel principal
 */

// ===== INICIALIZACIÓN DE SESIÓN =====
// Continuar sesión PHP existente para verificar autenticación
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ===== VERIFICACIÓN DE AUTENTICACIÓN =====
// Si no hay sesión activa, redirigir al login
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

// ===== OBTENCIÓN DE DATOS DE USUARIO =====
// Extraer información del usuario desde variables de sesión
$usuario = $_SESSION['usuario'] ?? 'Usuario';
$rol = $_SESSION['rol'] ?? 'usuario';

// ===== CARGA DE CONFIGURACIÓN PARA LOGO =====
// Cargar configuración desde archivo INI para obtener el logo personalizado
$config = [];
if (file_exists('config.ini')) {
    $config = parse_ini_file('config.ini', true);
}
?>
<!-- ===== ESTRUCTURA HTML SEMÁNTICA ===== -->
<!DOCTYPE html>
<html lang="es">
<head>
    <!-- ===== META TAGS Y CONFIGURACIÓN ===== -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenido - ArduinoSoft Monitor Ambiental</title>
      <!-- ===== RECURSOS EXTERNOS ===== -->
    <link rel="stylesheet" href="styles.css">
    <meta name="description" content="Bienvenido al sistema de monitoreo ambiental">
    <!-- Meta refresh removido - solo redirección por JavaScript -->
    <!-- Los estilos específicos para countdown han sido trasladados a styles.css -->
</head>

<!-- ===== CUERPO CON DISEÑO DE BIENVENIDA ===== -->
<body class="login-body">
    <div class="login-container">
        <div class="login-card text-center">
              <!-- ===== ENCABEZADO DE APLICACIÓN ===== -->
            <header class="app-header">
                <div class="logo-container">
                    <?php 
                    // Verificar si existe un logo personalizado en la configuración
                    $logo_path = 'media/logo.png'; // Logo por defecto
                    if (isset($config['sistema']['logo']) && !empty($config['sistema']['logo']) && file_exists($config['sistema']['logo'])) {
                        $logo_path = $config['sistema']['logo'];
                    }
                    ?>
                    <img src="<?php echo htmlspecialchars($logo_path); ?>" alt="Logo ArduinoSoft" class="app-logo">
                </div>
                <div class="title-container">
                    <h1>ArduinoSoft Monitor Ambiental</h1>
                </div>
            </header>
              <!-- ===== CONTENIDO PRINCIPAL DE BIENVENIDA ===== -->
            <main>
                <!-- ===== MENSAJE DE BIENVENIDA PERSONALIZADO ===== -->
                <!-- Alert de éxito con saludo personalizado al usuario -->
                <div class="alert alert-success" role="alert">
                    <h2>¡Bienvenido, <?php echo htmlspecialchars($usuario); ?>!</h2>
                    <p>Inicio de sesión exitoso</p>
                </div>
                
                <!-- ===== CONTADOR REGRESIVO VISUAL ===== -->
                <!-- Contenedor para countdown con barra de progreso -->                <div id="countdown-container" class="countdown-visual">
                    <div class="countdown-content">
                        <div class="countdown-circle">
                            <span id="countdown-number">5</span>
                        </div>
                        <div class="countdown-text">
                            <h3>Accediendo al Panel Principal</h3>
                            <p>Preparando su espacio de trabajo...</p>
                        </div>
                        <div class="countdown-status">
                            <span class="status-icon">⚡</span>
                            <div class="status-text">Cargando</div>
                        </div>
                    </div>
                    <!-- Barra de progreso visual mejorada -->
                    <div class="progress-bar-container">
                        <div id="progress" class="progress-bar"></div>
                    </div>
                </div>
                  <!-- ===== BOTÓN DE ACCESO INMEDIATO ===== -->
                <!-- Opción para acceder sin esperar el countdown -->
                <div class="mt-xl">
                    <a href="panel.php" class="btn btn-primary">
                        Ir al Panel Ahora
                    </a>
                </div>
            </main>
        </div>
    </div>    <!-- ===== JAVASCRIPT PARA COUNTDOWN Y REDIRECCIÓN ===== -->
    <script>
        // ===== VARIABLES GLOBALES =====
        let countdownTimer = null;
        let currentCountdown = 5;
        
        // ===== MENSAJES DEL COUNTDOWN =====
        const countdownMessages = [
            { 
                title: "Accediendo al Panel Principal", 
                subtitle: "Preparando su espacio de trabajo...",
                icon: "⚡",
                status: "Cargando"
            },
            { 
                title: "Verificando Configuración", 
                subtitle: "Cargando parámetros del sistema...",
                icon: "⚙️",
                status: "Config"
            },
            { 
                title: "Verificando Permisos", 
                subtitle: "Configurando acceso al sistema...",
                icon: "🔐",
                status: "Validando"
            },
            { 
                title: "Iniciando Sesión", 
                subtitle: "Cargando datos del usuario...",
                icon: "👤",
                status: "Iniciando"
            },
            { 
                title: "¡Listo para Comenzar!", 
                subtitle: "Redirigiendo al panel...",
                icon: "✅",
                status: "Completo"
            }
        ];
        
        // ===== FUNCIÓN PARA ACTUALIZAR INTERFAZ =====
        function updateCountdownInterface(messageIndex) {
            try {
                const message = countdownMessages[messageIndex];
                if (!message) return;
                
                const titleElement = document.querySelector('.countdown-text h3');
                const subtitleElement = document.querySelector('.countdown-text p');
                const iconElement = document.querySelector('.status-icon');
                const statusElement = document.querySelector('.status-text');
                
                if (titleElement) titleElement.textContent = message.title;
                if (subtitleElement) subtitleElement.textContent = message.subtitle;
                if (iconElement) iconElement.textContent = message.icon;
                if (statusElement) statusElement.textContent = message.status;
                
                console.log(`Interfaz actualizada: ${message.title}`);
            } catch (error) {
                console.error('Error actualizando interfaz:', error);
            }
        }
        
        // ===== FUNCIÓN PRINCIPAL DEL COUNTDOWN =====
        function startCountdown() {
            console.log('🚀 Iniciando countdown desde', currentCountdown);
            
            // Elementos del DOM
            const numberElement = document.getElementById('countdown-number');
            const progressElement = document.getElementById('progress');
            
            if (!numberElement || !progressElement) {
                console.error('❌ Elementos del countdown no encontrados');
                // Redirección de emergencia
                setTimeout(() => window.location.href = 'panel.php', 1000);
                return;
            }
            
            // Inicializar interfaz
            updateCountdownInterface(0);
            
            // Iniciar barra de progreso
            setTimeout(() => {
                progressElement.style.width = '20%';
            }, 200);
            
            // Timer principal
            countdownTimer = setInterval(() => {
                console.log(`⏰ Countdown tick: ${currentCountdown} -> ${currentCountdown - 1}`);
                
                currentCountdown--;
                numberElement.textContent = currentCountdown;
                      // Actualizar barra de progreso
                const progressPercent = ((5 - currentCountdown) / 5) * 100;
                progressElement.style.width = progressPercent + '%';
                console.log(`Progreso: ${progressPercent}%`);
                
                // Actualizar mensaje si countdown > 0
                if (currentCountdown > 0) {
                    const messageIndex = 5 - currentCountdown;
                    if (messageIndex < countdownMessages.length) {
                        updateCountdownInterface(messageIndex);
                    }
                }
                
                // Cuando llega a 0
                if (currentCountdown <= 0) {
                    console.log('🎯 Countdown completado');
                    clearInterval(countdownTimer);
                    
                    // Estado final
                    updateCountdownInterface(4); // Último mensaje
                    numberElement.textContent = '✓';
                    numberElement.style.color = '#28a745';
                    numberElement.style.fontSize = '28px';
                    
                    // Completar progreso
                    progressElement.style.width = '100%';
                    progressElement.style.background = 'linear-gradient(90deg, #28a745 0%, #20c997 100%)';
                    
                    // Redirección
                    setTimeout(() => {
                        console.log('🔄 Redirigiendo a panel.php');
                        window.location.href = 'panel.php';
                    }, 1000);
                }
            }, 1000);
        }
        
        // ===== INICIALIZACIÓN =====
        document.addEventListener('DOMContentLoaded', function() {
            console.log('✅ DOM cargado, iniciando countdown en 500ms');
            
            // Pequeña pausa para asegurar que todo esté renderizado
            setTimeout(() => {
                startCountdown();
            }, 500);
            
            // Fallback de seguridad
            setTimeout(() => {
                if (window.location.pathname.includes('callback.php')) {
                    console.log('⚠️ Fallback activado - redirigiendo');
                    window.location.href = 'panel.php';
                }
            }, 10000);
        });
        
        // ===== DEBUG INFO =====
        console.log('📋 Callback.php JavaScript cargado');
    </script>
</body>
</html>
