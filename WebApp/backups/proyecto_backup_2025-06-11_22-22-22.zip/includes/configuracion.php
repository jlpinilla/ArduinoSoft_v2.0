<?php
/**
 * =====================================================
 * MÓDULO DE CONFIGURACIÓN DEL SISTEMA - SUITE AMBIENTAL
 * =====================================================
 * Sistema completo de edición de configuración del sistema
 * Permite modificar parámetros ambientales, configuración general
 * y opciones del monitor público desde el panel de administración.
 * 
 * Funcionalidades principales:
 * - Edición de umbrales ambientales (temperatura, humedad, ruido, CO2, lux)
 * - Configuración general del sistema (nombre, versión, timezone)
 * - Configuración del monitor público (refresh, modo pantalla)
 * - Validación de parámetros y respaldo automático
 * - Interfaz intuitiva con validación en tiempo real
 */

// ===== CONTROL DE SEGURIDAD Y SESIÓN =====
// Verificar que el usuario esté autenticado y sea administrador
if (session_status() === PHP_SESSION_NONE) {
   session_start();
}

if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'admin') {
    header("Location: index.php");
    exit();
}

// ===== VARIABLES DE CONTROL =====
$action = $_POST['action'] ?? $_GET['action'] ?? 'edit';
$message = '';
$error = '';

// ===== VERIFICAR DIRECTORIO DE BACKUPS =====
$backup_dir = 'configbackup';
if (!is_dir($backup_dir)) {
    if (!mkdir($backup_dir, 0755, true)) {
        $error = 'No se pudo crear el directorio de backups. Verifique los permisos.';
    }
}

// ===== CARGA DE CONFIGURACIÓN ACTUAL =====
$config_actual = [];
$config_exists = file_exists('config.ini');

if ($config_exists) {
    $config_actual = parse_ini_file('config.ini', true);
} else {
    $error = 'No se encontró el archivo de configuración config.ini';
}

// ===== PROCESAMIENTO DE FORMULARIO =====
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'save') {
    try {        // === Validar datos recibidos ===
        $nueva_config = [
            'database' => $config_actual['database'] ?? [], // Preservar config BD
            'sistema' => [
                'nombre' => trim($_POST['sistema_nombre'] ?? 'Suite Ambiental'),
                'version' => trim($_POST['sistema_version'] ?? '2.0'),
                'timezone' => trim($_POST['sistema_timezone'] ?? '+02:00'),
                'log_level' => trim($_POST['sistema_log_level'] ?? 'info'),
                'logo' => $config_actual['sistema']['logo'] ?? 'media/logo.png' // Preservar logo actual
            ],            'referencias' => [
                'temperatura_max' => floatval($_POST['temperatura_max'] ?? 25),
                'humedad_max' => floatval($_POST['humedad_max'] ?? 48),
                'ruido_max' => floatval($_POST['ruido_max'] ?? 35),
                'co2_max' => intval($_POST['co2_max'] ?? 1000),
                'lux_min' => intval($_POST['lux_min'] ?? 195)
            ],            'publico' => [
                'titulo' => trim($_POST['publico_titulo'] ?? 'Monitor Ambiental'),
                'subtitulo' => trim($_POST['publico_subtitulo'] ?? 'Sistema de Sensores Arduino'),
                'color_fondo' => trim($_POST['publico_color_fondo'] ?? '#667eea'),
                'color_secundario' => trim($_POST['publico_color_secundario'] ?? '#764ba2'),
                'color_texto' => trim($_POST['publico_color_texto'] ?? '#ffffff'),
                'refresh_interval' => intval($_POST['publico_refresh_interval'] ?? 60)
            ]
        ];
        
        // === Validaciones de seguridad ===
        $errores_validacion = [];
        
        // Validar umbrales ambientales
        if ($nueva_config['referencias']['temperatura_max'] < 15 || $nueva_config['referencias']['temperatura_max'] > 50) {
            $errores_validacion[] = 'Temperatura máxima debe estar entre 15°C y 50°C';
        }
        if ($nueva_config['referencias']['humedad_max'] < 30 || $nueva_config['referencias']['humedad_max'] > 90) {
            $errores_validacion[] = 'Humedad máxima debe estar entre 30% y 90%';
        }
        if ($nueva_config['referencias']['ruido_max'] < 20 || $nueva_config['referencias']['ruido_max'] > 100) {
            $errores_validacion[] = 'Ruido máximo debe estar entre 20dB y 100dB';
        }
        if ($nueva_config['referencias']['co2_max'] < 300 || $nueva_config['referencias']['co2_max'] > 5000) {
            $errores_validacion[] = 'CO2 máximo debe estar entre 300ppm y 5000ppm';
        }        if ($nueva_config['referencias']['lux_min'] < 50 || $nueva_config['referencias']['lux_min'] > 1000) {
            $errores_validacion[] = 'Iluminación mínima debe estar entre 50lux y 1000lux';
        }
          // Validar configuración pública
        if (strlen($nueva_config['publico']['titulo']) < 3 || strlen($nueva_config['publico']['titulo']) > 50) {
            $errores_validacion[] = 'El título debe tener entre 3 y 50 caracteres';
        }
        if (strlen($nueva_config['publico']['subtitulo']) < 3 || strlen($nueva_config['publico']['subtitulo']) > 80) {
            $errores_validacion[] = 'El subtítulo debe tener entre 3 y 80 caracteres';
        }
        if (!preg_match('/^#[0-9A-Fa-f]{6}$/', $nueva_config['publico']['color_fondo'])) {
            $errores_validacion[] = 'El color de fondo debe ser un código hexadecimal válido (ej: #667eea)';
        }
        if (!preg_match('/^#[0-9A-Fa-f]{6}$/', $nueva_config['publico']['color_secundario'])) {
            $errores_validacion[] = 'El color secundario debe ser un código hexadecimal válido (ej: #764ba2)';
        }
        if (!preg_match('/^#[0-9A-Fa-f]{6}$/', $nueva_config['publico']['color_texto'])) {
            $errores_validacion[] = 'El color del texto debe ser un código hexadecimal válido (ej: #ffffff)';
        }
        if ($nueva_config['publico']['refresh_interval'] < 60 || $nueva_config['publico']['refresh_interval'] > 3600) {
            $errores_validacion[] = 'El tiempo de actualización debe estar entre 60 segundos y 60 minutos (3600 segundos)';
        }
        
        // === Procesamiento del archivo de logo ===
        if (isset($_FILES['sistema_logo']) && $_FILES['sistema_logo']['error'] === UPLOAD_ERR_OK) {
            $upload_file = $_FILES['sistema_logo'];
            $allowed_types = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif'];
            
            // Validar tipo de archivo
            if (in_array($upload_file['type'], $allowed_types)) {
                // Validar tamaño (máximo 2MB)
                if ($upload_file['size'] <= 2 * 1024 * 1024) {
                    // Crear directorio media si no existe
                    if (!is_dir('media')) {
                        mkdir('media', 0755, true);
                    }
                    
                    // Generar nombre único para el archivo
                    $extension = pathinfo($upload_file['name'], PATHINFO_EXTENSION);
                    $logo_filename = 'logo_' . time() . '.' . $extension;
                    $logo_path = 'media/' . $logo_filename;
                    
                    // Mover archivo subido
                    if (move_uploaded_file($upload_file['tmp_name'], $logo_path)) {
                        // Eliminar logo anterior si no es el por defecto
                        $logo_anterior = $config_actual['sistema']['logo'] ?? '';
                        if (!empty($logo_anterior) && $logo_anterior !== 'media/logo.png' && file_exists($logo_anterior)) {
                            unlink($logo_anterior);
                        }
                        
                        // Actualizar configuración con nuevo logo
                        $nueva_config['sistema']['logo'] = $logo_path;
                    } else {
                        $errores_validacion[] = 'Error al subir el archivo de logo';
                    }
                } else {
                    $errores_validacion[] = 'El archivo de logo debe ser menor a 2MB';
                }
            } else {
                $errores_validacion[] = 'El logo debe ser una imagen válida (PNG, JPG, GIF)';
            }
        }
        
        if (!empty($errores_validacion)) {
            $error = 'Errores de validación: ' . implode(', ', $errores_validacion);} else {
            // === Crear respaldo de la configuración actual ===
            $backup_filename = 'configbackup/config_backup_' . date('Y-m-d_H-i-s') . '.ini';
            if ($config_exists) {
                copy('config.ini', $backup_filename);
            }
            
            // === Generar nuevo archivo config.ini ===
            $config_content = "; Configuración del Sistema de Monitoreo Ambiental\n";
            $config_content .= "; Actualizado el " . date('Y-m-d H:i:s') . " por " . $_SESSION['usuario'] . "\n\n";
            
            // Sección de Base de Datos (preservar)
            if (isset($nueva_config['database'])) {
                $config_content .= "[database]\n";
                foreach ($nueva_config['database'] as $key => $value) {
                    $config_content .= "{$key} = \"{$value}\"\n";
                }
                $config_content .= "\n";
            }
            
            // Sección de Sistema
            $config_content .= "[sistema]\n";
            foreach ($nueva_config['sistema'] as $key => $value) {
                $config_content .= "{$key} = \"{$value}\"\n";
            }
            $config_content .= "\n";
              // Sección de Referencias Ambientales
            $config_content .= "[referencias]\n";
            $config_content .= "temperatura_max = {$nueva_config['referencias']['temperatura_max']}\n";
            $config_content .= "humedad_max = {$nueva_config['referencias']['humedad_max']}\n";
            $config_content .= "ruido_max = {$nueva_config['referencias']['ruido_max']}\n";
            $config_content .= "co2_max = {$nueva_config['referencias']['co2_max']}\n";
            $config_content .= "lux_min = {$nueva_config['referencias']['lux_min']}\n\n";
              // Sección de Configuración Pública
            $config_content .= "[publico]\n";
            $config_content .= "; Configuración específica para el monitor público\n";
            $config_content .= "titulo = \"{$nueva_config['publico']['titulo']}\"\n";
            $config_content .= "subtitulo = \"{$nueva_config['publico']['subtitulo']}\"\n";
            $config_content .= "color_fondo = \"{$nueva_config['publico']['color_fondo']}\"\n";
            $config_content .= "color_secundario = \"{$nueva_config['publico']['color_secundario']}\"\n";
            $config_content .= "color_texto = \"{$nueva_config['publico']['color_texto']}\"\n";
            $config_content .= "refresh_interval = {$nueva_config['publico']['refresh_interval']}\n\n";// Sección de Azure/Teams
            if (isset($nueva_config['azure'])) {
                $config_content .= "[azure]\n";
                $config_content .= "; Configuración para alertas en Microsoft Teams\n";
                foreach ($nueva_config['azure'] as $key => $value) {
                    $config_content .= "{$key} = \"{$value}\"\n";
                }
                $config_content .= "\n";
            }
              // === Guardar nueva configuración ===
            if (file_put_contents('config.ini', $config_content)) {
                $message = 'Configuración guardada exitosamente. Respaldo creado: ' . $backup_filename;
                  // Registrar cambio en log
                $log_entry = "\n### " . date('Y-m-d H:i:s') . " - Configuración Actualizada\n";
                $log_entry .= "**Usuario:** " . $_SESSION['usuario'] . "\n";
                $log_entry .= "**Cambios realizados:**\n";
                $log_entry .= "- Umbrales ambientales modificados\n";
                $log_entry .= "- Configuración del sistema actualizada\n";
                if (isset($_FILES['sistema_logo']) && $_FILES['sistema_logo']['error'] === UPLOAD_ERR_OK) {
                    $log_entry .= "- Logo del sistema actualizado\n";
                }                $log_entry .= "- Respaldo generado: {$backup_filename}\n";
                $log_entry .= "---\n";
                
                file_put_contents('logs/cambios.log', $log_entry, FILE_APPEND);
                
                // Recargar configuración
                $config_actual = parse_ini_file('config.ini', true);
                
                // Si se actualizó el logo, marcar para refresh automático
                if (isset($_FILES['sistema_logo']) && $_FILES['sistema_logo']['error'] === UPLOAD_ERR_OK) {
                    $message .= ' El logo se ha actualizado correctamente. La página se refrescará automáticamente para mostrar los cambios.';
                    echo '<script>
                        setTimeout(function() {
                            // Forzar recarga de favicon y logo
                            const favicon = document.querySelector("link[rel*=\'icon\']") || document.createElement("link");
                            favicon.type = "image/png";
                            favicon.rel = "icon";
                            favicon.href = "' . htmlspecialchars($nueva_config['sistema']['logo']) . '?v=' . time() . '";
                            document.getElementsByTagName("head")[0].appendChild(favicon);
                            
                            // Recargar página después de 2 segundos
                            setTimeout(function() {
                                window.location.reload();
                            }, 2000);
                        }, 1000);
                    </script>';
                }
            } else {
                $error = 'Error al guardar la configuración. Verifique los permisos del archivo.';
            }
        }
        
    } catch (Exception $e) {
        $error = 'Error al procesar la configuración: ' . $e->getMessage();
    }
}

// ===== OBTENER VALORES ACTUALES PARA EL FORMULARIO =====
$valores = [
    'sistema_nombre' => $config_actual['sistema']['nombre'] ?? 'Suite Ambiental',
    'sistema_version' => $config_actual['sistema']['version'] ?? '2.0',
    'sistema_timezone' => $config_actual['sistema']['timezone'] ?? '+02:00',
    'sistema_log_level' => $config_actual['sistema']['log_level'] ?? 'info',
    'sistema_logo' => $config_actual['sistema']['logo'] ?? 'media/logo.png',
    'temperatura_max' => $config_actual['referencias']['temperatura_max'] ?? 25,
    'humedad_max' => $config_actual['referencias']['humedad_max'] ?? 48,
    'ruido_max' => $config_actual['referencias']['ruido_max'] ?? 35,
    'co2_max' => $config_actual['referencias']['co2_max'] ?? 1000,
    'lux_min' => $config_actual['referencias']['lux_min'] ?? 195,    'publico_titulo' => $config_actual['publico']['titulo'] ?? 'Monitor Ambiental',
    'publico_subtitulo' => $config_actual['publico']['subtitulo'] ?? 'Sistema de Sensores Arduino',
    'publico_color_fondo' => $config_actual['publico']['color_fondo'] ?? '#667eea',
    'publico_color_secundario' => $config_actual['publico']['color_secundario'] ?? '#764ba2',
    'publico_color_texto' => $config_actual['publico']['color_texto'] ?? '#ffffff',
    'publico_refresh_interval' => $config_actual['publico']['refresh_interval'] ?? 60,
    'azure_enabled' => isset($config_actual['azure']['enabled']) ? ($config_actual['azure']['enabled'] === 'true') : false,
    'azure_auth_type' => $config_actual['azure']['auth_type'] ?? 'client_credentials',
    'azure_tenant_id' => $config_actual['azure']['tenant_id'] ?? '',
    'azure_client_id' => $config_actual['azure']['client_id'] ?? '',
    'azure_client_secret' => $config_actual['azure']['client_secret'] ?? '',
    'azure_username' => $config_actual['azure']['username'] ?? '',
    'azure_password' => $config_actual['azure']['password'] ?? '',
    'azure_secret_id' => $config_actual['azure']['secret_id'] ?? '',    'azure_teams_chat_id' => $config_actual['azure']['teams_chat_id'] ?? '',
    'azure_alert_template' => $config_actual['azure']['alert_template'] ?? 'El sensor {nombre} ubicado en {ubicacion} ha generado una alerta: {parametro} = {valor} (límite: {limite})'
];
?>

<!-- ===== INTERFAZ DE CONFIGURACIÓN DEL SISTEMA ===== -->
<div class="config-container">
    
    <!-- ===== ENCABEZADO DE LA PÁGINA ===== -->
    <h2 class="page-title">⚙️ Configuración del Sistema</h2>
    <p class="page-subtitle">Modifique los parámetros de funcionamiento del sistema de monitoreo ambiental</p>
    
    <!-- ===== MENSAJES DE ESTADO ===== -->
    <?php if ($message): ?>
        <div class="alert alert-success" role="alert">
            <strong>✅ Éxito:</strong> <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-error" role="alert">
            <strong>❌ Error:</strong> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>
    
    <!-- ===== FORMULARIO PRINCIPAL DE CONFIGURACIÓN ===== -->
    <form method="POST" action="" enctype="multipart/form-data" novalidate class="config-form">
        <input type="hidden" name="action" value="save">
        
        <!-- ===== SECCIÓN: CONFIGURACIÓN GENERAL DEL SISTEMA ===== -->
        <div class="form-section">
            <h3>🏢 Configuración General</h3>
            <p>Parámetros básicos del sistema y la organización</p>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="sistema_nombre" class="form-label">Nombre del Sistema</label>
                    <input 
                        type="text" 
                        id="sistema_nombre" 
                        name="sistema_nombre" 
                        class="form-control"
                        value="<?php echo htmlspecialchars($valores['sistema_nombre']); ?>"
                        placeholder="Suite Ambiental"
                    >
                    <small class="form-help">Nombre que aparecerá en la interfaz del sistema</small>
                </div>
                
                <div class="form-group">
                    <label for="sistema_version" class="form-label">Versión</label>
                    <input 
                        type="text" 
                        id="sistema_version" 
                        name="sistema_version" 
                        class="form-control"
                        value="<?php echo htmlspecialchars($valores['sistema_version']); ?>"
                        placeholder="2.0"
                    >
                    <small class="form-help">Versión actual del software</small>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="sistema_timezone" class="form-label">Zona Horaria</label>                    <select id="sistema_timezone" name="sistema_timezone" class="form-control">
                        <option value="+02:00" <?php echo $valores['sistema_timezone'] === '+02:00' ? 'selected' : ''; ?>>Europa/Madrid (+02:00) - Hora de Verano</option>
                        <option value="+01:00" <?php echo $valores['sistema_timezone'] === '+01:00' ? 'selected' : ''; ?>>Europa/París (+01:00) - Hora de Invierno</option>
                        <option value="+00:00" <?php echo $valores['sistema_timezone'] === '+00:00' ? 'selected' : ''; ?>>UTC (+00:00)</option>
                        <option value="-05:00" <?php echo $valores['sistema_timezone'] === '-05:00' ? 'selected' : ''; ?>>América/Nueva_York (-05:00)</option>
                    </select>
                    <small class="form-help">Zona horaria para fechas y registros</small>
                </div>
                
                <div class="form-group">
                    <label for="sistema_log_level" class="form-label">Nivel de Log</label>
                    <select id="sistema_log_level" name="sistema_log_level" class="form-control">
                        <option value="debug" <?php echo $valores['sistema_log_level'] === 'debug' ? 'selected' : ''; ?>>Debug (Detallado)</option>
                        <option value="info" <?php echo $valores['sistema_log_level'] === 'info' ? 'selected' : ''; ?>>Info (Normal)</option>
                        <option value="warning" <?php echo $valores['sistema_log_level'] === 'warning' ? 'selected' : ''; ?>>Warning (Solo advertencias)</option>
                        <option value="error" <?php echo $valores['sistema_log_level'] === 'error' ? 'selected' : ''; ?>>Error (Solo errores)</option>
                    </select>
                    <small class="form-help">Nivel de detalle para los logs del sistema</small>
                </div>            </div>
        </div>
        
        <!-- ===== SECCIÓN: PERSONALIZACIÓN DEL LOGO ===== -->
        <div class="form-section">
            <h3>🎨 Personalización del Logo</h3>
            <p>Configure el logo que aparece en la página de inicio</p>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="sistema_logo" class="form-label">Archivo de Logo</label>
                    <div class="file-input-container">
                        <input 
                            type="file" 
                            id="sistema_logo" 
                            name="sistema_logo" 
                            class="form-control file-input"
                            accept="image/*"
                            onchange="previewLogo(this)"
                        >
                        <small class="form-help">Formatos soportados: PNG, JPG, GIF. Tamaño recomendado: 80x80 píxeles</small>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Vista Previa Actual</label>
                    <div class="logo-preview-container">
                        <?php 
                        $current_logo = $valores['sistema_logo'] ?? 'media/logo.png';
                        if (file_exists($current_logo)) {
                        ?>
                            <img id="logo-preview" src="<?php echo htmlspecialchars($current_logo); ?>" 
                                 alt="Logo actual" class="logo-preview">
                            <div class="logo-info">
                                <small>Logo actual: <?php echo basename($current_logo); ?></small><br>
                                <button type="button" onclick="resetLogo()" class="btn btn-sm btn-secondary">
                                    🔄 Restaurar Logo Original
                                </button>
                            </div>
                        <?php } else { ?>
                            <div class="no-logo">
                                <span>📷</span>
                                <p>No hay logo configurado</p>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- ===== SECCIÓN: UMBRALES AMBIENTALES ===== -->
        <div class="form-section">
            <h3>🌡️ Umbrales de Alerta Ambiental</h3>
            <p>Configure los límites que determinarán cuándo un sensor está en estado de alerta</p>
            
            <div class="alert alert-info">
                <strong>ℹ️ Información:</strong> Los valores que superen estos umbrales aparecerán marcados en rojo en todo el sistema
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="temperatura_max" class="form-label">🌡️ Temperatura Máxima</label>
                    <div class="input-group">
                        <input 
                            type="number" 
                            id="temperatura_max" 
                            name="temperatura_max" 
                            class="form-control"
                            value="<?php echo $valores['temperatura_max']; ?>"
                            min="15" 
                            max="50" 
                            step="0.1"
                            required
                        >
                        <span class="input-suffix">°C</span>
                    </div>
                    <small class="form-help">Rango: 15°C - 50°C. Actual: <?php echo $valores['temperatura_max']; ?>°C</small>
                </div>
                
                <div class="form-group">
                    <label for="humedad_max" class="form-label">💧 Humedad Máxima</label>
                    <div class="input-group">
                        <input 
                            type="number" 
                            id="humedad_max" 
                            name="humedad_max" 
                            class="form-control"
                            value="<?php echo $valores['humedad_max']; ?>"
                            min="30" 
                            max="90" 
                            step="0.1"
                            required
                        >
                        <span class="input-suffix">%</span>
                    </div>
                    <small class="form-help">Rango: 30% - 90%. Actual: <?php echo $valores['humedad_max']; ?>%</small>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="ruido_max" class="form-label">🔊 Ruido Máximo</label>
                    <div class="input-group">
                        <input 
                            type="number" 
                            id="ruido_max" 
                            name="ruido_max" 
                            class="form-control"
                            value="<?php echo $valores['ruido_max']; ?>"
                            min="20" 
                            max="100" 
                            step="0.1"
                            required
                        >
                        <span class="input-suffix">dB</span>
                    </div>
                    <small class="form-help">Rango: 20dB - 100dB. Actual: <?php echo $valores['ruido_max']; ?>dB</small>
                </div>
                
                <div class="form-group">
                    <label for="co2_max" class="form-label">☁️ CO₂ Máximo</label>
                    <div class="input-group">
                        <input 
                            type="number" 
                            id="co2_max" 
                            name="co2_max" 
                            class="form-control"
                            value="<?php echo $valores['co2_max']; ?>"
                            min="300" 
                            max="5000" 
                            step="1"
                            required
                        >
                        <span class="input-suffix">ppm</span>
                    </div>
                    <small class="form-help">Rango: 300ppm - 5000ppm. Actual: <?php echo $valores['co2_max']; ?>ppm</small>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="lux_min" class="form-label">💡 Iluminación Mínima</label>
                    <div class="input-group">
                        <input 
                            type="number" 
                            id="lux_min" 
                            name="lux_min" 
                            class="form-control"
                            value="<?php echo $valores['lux_min']; ?>"
                            min="50" 
                            max="1000" 
                            step="1"
                            required
                        >
                        <span class="input-suffix">lux</span>
                    </div>
                    <small class="form-help">Rango: 50lux - 1000lux. Actual: <?php echo $valores['lux_min']; ?>lux</small>
                </div>
                
                <div class="form-group">
                    <!-- Espacio para mantener el layout -->
                </div>
            </div>        </div>
        
        <!-- ===== SECCIÓN: CONFIGURACIÓN DEL MONITOR PÚBLICO ===== -->
        <div class="form-section">
            <h3>🖥️ Configuración del Monitor Público</h3>
            <p>Personalice la apariencia y comportamiento de la página pública de monitoreo</p>
            
            <div class="alert alert-info">
                <strong>ℹ️ Información:</strong> Esta configuración afecta únicamente a la página pública (public.php) visible sin autenticación
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="publico_titulo" class="form-label">📝 Título Principal</label>
                    <input 
                        type="text" 
                        id="publico_titulo" 
                        name="publico_titulo" 
                        class="form-control"
                        value="<?php echo htmlspecialchars($valores['publico_titulo']); ?>"
                        placeholder="Monitor Ambiental"
                        maxlength="50"
                    >
                    <small class="form-help">Título que aparece en la parte superior del monitor público</small>
                </div>
                
                <div class="form-group">
                    <label for="publico_subtitulo" class="form-label">📄 Subtítulo</label>
                    <input 
                        type="text" 
                        id="publico_subtitulo" 
                        name="publico_subtitulo" 
                        class="form-control"
                        value="<?php echo htmlspecialchars($valores['publico_subtitulo']); ?>"
                        placeholder="Sistema de Sensores Arduino"
                        maxlength="80"
                    >
                    <small class="form-help">Subtítulo descriptivo del sistema</small>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="publico_color_fondo" class="form-label">🎨 Color de Fondo</label>
                    <div class="color-input-container">
                        <input 
                            type="color" 
                            id="publico_color_fondo" 
                            name="publico_color_fondo" 
                            class="form-control color-input"
                            value="<?php echo $valores['publico_color_fondo']; ?>"
                            title="Seleccionar color de fondo"
                        >
                        <input 
                            type="text" 
                            class="form-control color-text"
                            value="<?php echo $valores['publico_color_fondo']; ?>"
                            readonly
                            style="margin-left: 10px; width: 100px;"
                        >
                    </div>                    <small class="form-help">Color de fondo del degradado principal. Color actual: <?php echo $valores['publico_color_fondo']; ?></small>
                </div>
                
                <div class="form-group">
                    <label for="publico_color_secundario" class="form-label">🌈 Color Secundario</label>
                    <div class="color-input-container">
                        <input 
                            type="color" 
                            id="publico_color_secundario" 
                            name="publico_color_secundario" 
                            class="form-control color-input"
                            value="<?php echo $valores['publico_color_secundario']; ?>"
                            title="Seleccionar color secundario del degradado"
                        >
                        <input 
                            type="text" 
                            class="form-control color-text"
                            value="<?php echo $valores['publico_color_secundario']; ?>"
                            readonly
                            style="margin-left: 10px; width: 100px;"
                        >
                    </div>
                    <small class="form-help">Color secundario del degradado. Color actual: <?php echo $valores['publico_color_secundario']; ?></small>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="publico_color_texto" class="form-label">📝 Color del Texto</label>
                    <div class="color-input-container">
                        <input 
                            type="color" 
                            id="publico_color_texto" 
                            name="publico_color_texto" 
                            class="form-control color-input"
                            value="<?php echo $valores['publico_color_texto']; ?>"
                            title="Seleccionar color del texto"
                        >
                        <input 
                            type="text" 
                            class="form-control color-text"
                            value="<?php echo $valores['publico_color_texto']; ?>"
                            readonly
                            style="margin-left: 10px; width: 100px;"
                        >
                    </div>
                    <small class="form-help">Color del texto en el monitor público. Color actual: <?php echo $valores['publico_color_texto']; ?></small>
                </div>
                
                <div class="form-group">
                    <label for="publico_refresh_interval" class="form-label">⏱️ Tiempo de Actualización</label>
                    <div class="input-group">
                        <input 
                            type="number" 
                            id="publico_refresh_interval" 
                            name="publico_refresh_interval" 
                            class="form-control"
                            value="<?php echo $valores['publico_refresh_interval']; ?>"
                            min="60" 
                            max="3600" 
                            step="30"
                            required
                        >
                        <span class="input-suffix">segundos</span>
                    </div>
                    <small class="form-help">Intervalo de auto-actualización (60 segundos - 60 minutos). Actual: <?php echo floor($valores['publico_refresh_interval'] / 60); ?> min <?php echo $valores['publico_refresh_interval'] % 60; ?>s</small>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">                    <label class="form-label">🎨 Vista Previa del Color</label>
                    <div class="color-preview-container">
                        <div id="color-preview" class="color-preview" 
                             style="background: linear-gradient(135deg, <?php echo $valores['publico_color_fondo']; ?> 0%, <?php echo $valores['publico_color_secundario']; ?> 100%);">
                            <div class="preview-content">
                                <h3 style="color: <?php echo $valores['publico_color_texto']; ?>; text-shadow: 2px 2px 4px rgba(0,0,0,0.3);">
                                    <?php echo htmlspecialchars($valores['publico_titulo']); ?>
                                </h3>
                                <p style="color: <?php echo $valores['publico_color_texto']; ?>; opacity: 0.9;">
                                    <?php echo htmlspecialchars($valores['publico_subtitulo']); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <small class="form-help">Vista previa de cómo se verá el encabezado del monitor público</small>
                </div>
                
                <div class="form-group">
                    <label class="form-label">📊 Configuración Actual</label>
                    <div class="config-summary">                        <div class="summary-item">
                            <strong>Actualización:</strong> Cada <?php echo $valores['publico_refresh_interval']; ?> segundos
                        </div>
                        <div class="summary-item">
                            <strong>Color Principal:</strong> <span style="color: <?php echo $valores['publico_color_fondo']; ?>;">●</span> <?php echo $valores['publico_color_fondo']; ?>
                        </div>
                        <div class="summary-item">
                            <strong>Color Secundario:</strong> <span style="color: <?php echo $valores['publico_color_secundario']; ?>;">●</span> <?php echo $valores['publico_color_secundario']; ?>
                        </div>
                        <div class="summary-item">
                            <strong>Color Texto:</strong> <span style="color: <?php echo $valores['publico_color_texto']; ?>;">●</span> <?php echo $valores['publico_color_texto']; ?>
                        </div>
                        <div class="summary-item">
                            <strong>Textos:</strong> Personalizados
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ===== INFORMACIÓN ADICIONAL ===== -->
        <div class="form-section">
            <h3>📋 Información del Sistema</h3>
            <div class="info-grid">
                <div class="info-item">
                    <span class="info-label">Configuración Actual:</span>
                    <span class="info-value"><?php echo $config_exists ? 'config.ini encontrado' : 'No encontrado'; ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Última Modificación:</span>
                    <span class="info-value"><?php echo $config_exists ? date('d/m/Y H:i:s', filemtime('config.ini')) : 'N/A'; ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Usuario Actual:</span>
                    <span class="info-value"><?php echo htmlspecialchars($_SESSION['usuario']); ?> (<?php echo htmlspecialchars($_SESSION['rol']); ?>)</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Base de Datos:</span>
                    <span class="info-value"><?php echo htmlspecialchars($config_actual['database']['database'] ?? 'No configurada'); ?></span>
                </div>
            </div>
        </div>
        
        <!-- ===== BOTONES DE ACCIÓN ===== -->
        <div class="form-actions">
            <button type="submit" class="btn btn-primary btn-lg">
                💾 Guardar Configuración
            </button>
            <a href="?seccion=dashboard" class="btn btn-secondary">
                ❌ Cancelar
            </a>
            <button type="button" onclick="resetForm()" class="btn btn-warning">
                🔄 Restaurar Valores
            </button>
        </div>
        
        <!-- ===== ADVERTENCIA DE SEGURIDAD ===== -->
        <div class="alert alert-warning">
            <strong>⚠️ Advertencia:</strong> 
            Los cambios en la configuración afectarán inmediatamente el funcionamiento del sistema. 
            Se creará automáticamente un respaldo de la configuración actual antes de guardar los cambios.
        </div>
    </form>
</div>

<!-- ===== SECCIÓN DE GESTIÓN DE BACKUPS ===== -->
<div class="config-panel">
    <h2>📦 Gestión de Copias de Seguridad</h2>
      <?php
    // Listar archivos de backup disponibles
    $backup_files = [];
    if (is_dir('configbackup')) {
        $files = scandir('configbackup');
        foreach ($files as $file) {
            if (preg_match('/^config_backup_.+\.ini$/', $file)) {
                $backup_files[] = [
                    'filename' => $file,
                    'path' => 'configbackup/' . $file,
                    'date' => filemtime('configbackup/' . $file),
                    'size' => filesize('configbackup/' . $file)
                ];
            }
        }
        // Ordenar por fecha (más reciente primero)
        usort($backup_files, function($a, $b) {
            return $b['date'] - $a['date'];
        });
    }
    ?>
    
    <div class="backup-info">
        <p><strong>Total de copias de seguridad:</strong> <?php echo count($backup_files); ?></p>
        <p><strong>Ubicación:</strong> <code>configbackup/</code></p>
    </div>
    
    <?php if (!empty($backup_files)): ?>
        <div class="backup-list">
            <h3>Archivos de Backup Disponibles</h3>
            <div class="table-responsive">
                <table class="backup-table">
                    <thead>
                        <tr>
                            <th>📅 Fecha de Creación</th>
                            <th>📄 Nombre del Archivo</th>
                            <th>📊 Tamaño</th>
                            <th>⚙️ Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($backup_files as $backup): ?>
                            <tr>
                                <td><?php echo date('d/m/Y H:i:s', $backup['date']); ?></td>
                                <td><code><?php echo htmlspecialchars($backup['filename']); ?></code></td>
                                <td><?php echo round($backup['size'] / 1024, 2); ?> KB</td>
                                <td>                                    <a href="<?php echo htmlspecialchars($backup['path']); ?>" 
                                       class="btn btn-sm btn-info" 
                                       download="<?php echo htmlspecialchars($backup['filename']); ?>"
                                       title="Descargar backup">
                                        💾 Descargar
                                    </a>
                                    <button type="button" 
                                            class="btn btn-sm btn-warning" 
                                            onclick="previewBackup('<?php echo htmlspecialchars($backup['path']); ?>')"
                                            title="Ver contenido">
                                        👁️ Ver
                                    </button>
                                    <button type="button" 
                                            class="btn btn-sm btn-danger" 
                                            onclick="deleteBackup('<?php echo htmlspecialchars($backup['filename']); ?>', '<?php echo htmlspecialchars($backup['path']); ?>')"
                                            title="Eliminar backup">
                                        🗑️ Eliminar
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-info">
            <strong>ℹ️ Información:</strong> 
            No hay copias de seguridad disponibles. Los backups se crearán automáticamente cuando modifique la configuración.
        </div>
    <?php endif; ?>
    
    <div class="backup-actions">
        <button type="button" class="btn btn-primary" onclick="createManualBackup()">
            💾 Crear Backup Manual
        </button>
        <?php if (count($backup_files) > 0): ?>
            <button type="button" class="btn btn-warning" onclick="cleanOldBackups()">
                🧹 Limpiar Backups Antiguos (>30 días)
            </button>
        <?php endif; ?>
    </div>
</div>

<!-- ===== MODAL PARA VISTA PREVIA DE BACKUP ===== -->
<div id="backupPreviewModal" class="modal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3>👁️ Vista Previa del Backup</h3>
            <span class="close" onclick="closeBackupPreview()">&times;</span>
        </div>
        <div class="modal-body">
            <pre id="backupContent" style="background: #f5f5f5; padding: 15px; border-radius: 5px; overflow-x: auto;"></pre>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeBackupPreview()">Cerrar</button>
        </div>
    </div>
</div>

<!-- ===== ESTILOS ESPECÍFICOS PARA CONFIGURACIÓN ===== -->
<style>
/* Estilos para la configuración pública */
.color-input-container {
    display: flex;
    align-items: center;
    gap: 10px;
}

.color-input {
    width: 60px !important;
    height: 40px !important;
    border: none !important;
    border-radius: 8px !important;
    cursor: pointer;
}

.color-text {
    font-family: monospace;
    text-transform: uppercase;
}

.color-preview-container {
    margin-top: 10px;
}

.color-preview {
    border-radius: 12px;
    padding: 20px;
    min-height: 100px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background 0.3s ease;
    border: 2px solid rgba(255,255,255,0.2);
}

.preview-content {
    text-align: center;
}

.preview-content h3 {
    margin: 0 0 8px 0;
    font-size: 1.5rem;
    font-weight: 300;
}

.preview-content p {
    margin: 0;
    font-size: 1.1rem;
    opacity: 0.9;
}

.config-summary {
    background: rgba(0, 120, 212, 0.1);
    padding: 15px;
    border-radius: 8px;
    border-left: 4px solid var(--primary-color);
}

.summary-item {
    margin: 8px 0;
    font-size: 0.9rem;
}

.summary-item strong {
    display: inline-block;
    width: 120px;
}

/* Animaciones para notificaciones */
@keyframes slideInRight {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

@keyframes slideOutRight {
    from {
        transform: translateX(0);
        opacity: 1;
    }
    to {
        transform: translateX(100%);
        opacity: 0;
    }
}

/* Estilos para notificaciones de logo */
.logo-notification {
    border-radius: 8px;
    padding: 15px;
    margin-bottom: 10px;
}

.logo-notification.alert-info {
    background-color: rgba(0, 120, 212, 0.1);
    border: 1px solid rgba(0, 120, 212, 0.3);
    color: #0078d4;
}

.logo-notification.alert-success {
    background-color: rgba(16, 124, 16, 0.1);
    border: 1px solid rgba(16, 124, 16, 0.3);
    color: #107c10;
}

.logo-notification.alert-warning {
    background-color: rgba(255, 152, 0, 0.1);
    border: 1px solid rgba(255, 152, 0, 0.3);
    color: #ff9800;
}

/* Estilos para mejorar la vista previa del logo */
.logo-preview {
    max-width: 100px;
    max-height: 100px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    transition: transform 0.2s ease;
}

.logo-preview:hover {
    transform: scale(1.05);
}

.logo-info {
    margin-top: 10px;
}

.logo-info small {
    display: block;
    margin-bottom: 8px;
}
</style>

<!-- ===== JAVASCRIPT PARA FUNCIONALIDAD INTERACTIVA ===== -->
<script>
// Función para restaurar valores originales del formulario
function resetForm() {
    if (confirm('¿Está seguro que desea restaurar todos los valores a su estado original?')) {
        // Recargar la página para restaurar valores
        window.location.reload();
    }
}

// Validación en tiempo real de los campos numéricos
document.addEventListener('DOMContentLoaded', function() {    // La configuración de visibilidad de Azure ha sido eliminada
    
    // Validar temperatura
    const tempInput = document.getElementById('temperatura_max');
    if (tempInput) {
        tempInput.addEventListener('input', function() {
            const value = parseFloat(this.value);
            if (value < 15 || value > 50) {
                this.style.borderColor = 'var(--error-color)';
            } else {
                this.style.borderColor = 'var(--success-color)';
            }
        });
    }
    
    // Validar humedad
    const humInput = document.getElementById('humedad_max');
    if (humInput) {
        humInput.addEventListener('input', function() {
            const value = parseFloat(this.value);
            if (value < 30 || value > 90) {
                this.style.borderColor = 'var(--error-color)';
            } else {
                this.style.borderColor = 'var(--success-color)';
            }
        });
    }
    
    // Validar ruido
    const ruidoInput = document.getElementById('ruido_max');
    if (ruidoInput) {
        ruidoInput.addEventListener('input', function() {
            const value = parseFloat(this.value);
            if (value < 20 || value > 100) {
                this.style.borderColor = 'var(--error-color)';
            } else {
                this.style.borderColor = 'var(--success-color)';
            }
        });
    }
    
    // Validar CO2
    const co2Input = document.getElementById('co2_max');
    if (co2Input) {
        co2Input.addEventListener('input', function() {
            const value = parseInt(this.value);
            if (value < 300 || value > 5000) {
                this.style.borderColor = 'var(--error-color)';
            } else {
                this.style.borderColor = 'var(--success-color)';
            }
        });
    }
      // Validar iluminación
    const luxInput = document.getElementById('lux_min');
    if (luxInput) {
        luxInput.addEventListener('input', function() {
            const value = parseInt(this.value);
            if (value < 50 || value > 1000) {
                this.style.borderColor = 'var(--error-color)';
            } else {
                this.style.borderColor = 'var(--success-color)';
            }
        });
    }
    
    // ===== VALIDACIONES PARA CONFIGURACIÓN PÚBLICA =====
    
    // Validar tiempo de refresco
    const refreshInput = document.getElementById('publico_refresh_interval');
    if (refreshInput) {
        refreshInput.addEventListener('input', function() {
            const value = parseInt(this.value);
            if (value < 60 || value > 3600) {
                this.style.borderColor = 'var(--error-color)';
            } else {
                this.style.borderColor = 'var(--success-color)';
            }
            
            // Actualizar información de tiempo
            const help = this.parentElement.nextElementSibling;
            if (help) {
                const minutos = Math.floor(value / 60);
                const segundos = value % 60;
                help.textContent = `Intervalo de auto-actualización (60 segundos - 60 minutos). Actual: ${minutos} min ${segundos}s`;
            }
        });
    }
      // Vista previa de colores
    const colorPrincipalInput = document.getElementById('publico_color_fondo');
    const colorSecundarioInput = document.getElementById('publico_color_secundario');
    const colorTextoInput = document.getElementById('publico_color_texto');
    const colorPreview = document.getElementById('color-preview');
    
    // Función para actualizar la vista previa completa
    function updateColorPreview() {
        if (!colorPreview) return;
        
        const colorPrincipal = colorPrincipalInput ? colorPrincipalInput.value : '#667eea';
        const colorSecundario = colorSecundarioInput ? colorSecundarioInput.value : '#764ba2';
        const colorTexto = colorTextoInput ? colorTextoInput.value : '#ffffff';
        
        // Actualizar fondo con degradado
        colorPreview.style.background = `linear-gradient(135deg, ${colorPrincipal} 0%, ${colorSecundario} 100%)`;
        
        // Actualizar colores de texto
        const titulo = colorPreview.querySelector('h3');
        const subtitulo = colorPreview.querySelector('p');
        
        if (titulo) {
            titulo.style.color = colorTexto;
        }
        if (subtitulo) {
            subtitulo.style.color = colorTexto;
        }
        
        // Actualizar campos de texto de colores
        const colorTexts = document.querySelectorAll('.color-text');
        colorTexts.forEach((textField, index) => {
            if (index === 0 && colorPrincipalInput) textField.value = colorPrincipal;
            if (index === 1 && colorSecundarioInput) textField.value = colorSecundario;
            if (index === 2 && colorTextoInput) textField.value = colorTexto;
        });
    }
    
    // Event listeners para los colores
    if (colorPrincipalInput) {
        colorPrincipalInput.addEventListener('input', updateColorPreview);
    }
    if (colorSecundarioInput) {
        colorSecundarioInput.addEventListener('input', updateColorPreview);
    }
    if (colorTextoInput) {
        colorTextoInput.addEventListener('input', updateColorPreview);
    }
    
    // Actualizar vista previa de títulos
    const tituloInput = document.getElementById('publico_titulo');
    const subtituloInput = document.getElementById('publico_subtitulo');
    
    if (tituloInput && colorPreview) {
        tituloInput.addEventListener('input', function() {
            const h3 = colorPreview.querySelector('h3');
            if (h3) h3.textContent = this.value || 'Monitor Ambiental';
        });
    }
    
    if (subtituloInput && colorPreview) {
        subtituloInput.addEventListener('input', function() {
            const p = colorPreview.querySelector('p');
            if (p) p.textContent = this.value || 'Sistema de Sensores Arduino';
        });
    }    
    // Las referencias a Azure/Teams han sido eliminadas
});

// Las funciones relacionadas con Azure/Teams han sido eliminadas    // Esta sección de código relacionada con Azure/Teams ha sido eliminada        // El código relacionado con la respuesta de Azure/Teams ha sido eliminado
    }).catch(error => {        // El código relacionado con el manejo de errores de Azure/Teams ha sido eliminado
        console.error('Error:', error);
    });
}

// Confirmación antes de guardar
document.querySelector('.config-form').addEventListener('submit', function(e) {
    if (!confirm('¿Está seguro que desea guardar estos cambios en la configuración?\n\nSe creará automáticamente un respaldo de la configuración actual.')) {
        e.preventDefault();
    }
});

// ===== FUNCIONES PARA GESTIÓN DE BACKUPS =====
function createManualBackup() {
    if (confirm('¿Está seguro de que desea crear una copia de seguridad manual de la configuración actual?')) {
        // Mostrar indicador de carga
        const button = event.target;
        const originalText = button.innerHTML;
        button.disabled = true;
        button.innerHTML = '⏳ Creando backup...';
        
        fetch('includes/backup_operations.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=create_backup'
        })
        .then(response => {
            console.log('Response status:', response.status);
            console.log('Response headers:', response.headers.get('content-type'));
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            // Verificar que la respuesta es JSON
            const contentType = response.headers.get('content-type');
            if (!contentType || !contentType.includes('application/json')) {
                return response.text().then(text => {
                    console.error('Respuesta no-JSON recibida:', text);
                    throw new Error('El servidor no devolvió JSON válido. Respuesta: ' + text.substring(0, 200));
                });
            }
            
            return response.json();
        })
        .then(data => {
            console.log('Datos recibidos:', data);
            
            if (data.success) {
                alert('✅ Backup creado exitosamente!\n\n' +
                      'Archivo: ' + data.filename + '\n' +
                      'Tamaño: ' + Math.round(data.size / 1024 * 100) / 100 + ' KB\n' +
                      'Fecha: ' + (data.timestamp || 'N/A'));
                location.reload(); // Recargar para mostrar el nuevo backup
            } else {
                alert('❌ Error al crear backup:\n' + data.error);
            }
        })
        .catch(error => {
            console.error('Error completo:', error);
            alert('❌ Error de conexión o del servidor:\n' + error.message + '\n\nVerifique:\n' +
                  '- Que el archivo includes/backup_operations.php existe\n' +
                  '- Los permisos del directorio configbackup/\n' +
                  '- La consola del navegador para más detalles');
        })
        .finally(() => {
            // Restaurar botón
            button.disabled = false;
            button.innerHTML = originalText;
        });
    }
}

function previewBackup(backupPath) {
    fetch(backupPath)
    .then(response => response.text())
    .then(content => {
        document.getElementById('backupContent').textContent = content;
        document.getElementById('backupPreviewModal').style.display = 'block';
    })
    .catch(error => {
        alert('❌ Error al cargar el backup: ' + error.message);
    });
}

function closeBackupPreview() {
    document.getElementById('backupPreviewModal').style.display = 'none';
}

function cleanOldBackups() {
    if (confirm('¿Está seguro de que desea eliminar las copias de seguridad con más de 30 días de antigüedad?')) {
        // Mostrar indicador de carga
        const button = event.target;
        const originalText = button.innerHTML;
        button.disabled = true;
        button.innerHTML = '⏳ Limpiando backups...';
        
        fetch('includes/backup_operations.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=clean_backups'
        })
        .then(response => {
            console.log('Response status:', response.status);
            console.log('Response headers:', response.headers.get('content-type'));
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            // Verificar que la respuesta es JSON
            const contentType = response.headers.get('content-type');
            if (!contentType || !contentType.includes('application/json')) {
                return response.text().then(text => {
                    console.error('Respuesta no-JSON recibida:', text);
                    throw new Error('El servidor no devolvió JSON válido. Respuesta: ' + text.substring(0, 200));
                });
            }
            
            return response.json();
        })
        .then(data => {
            console.log('Datos recibidos:', data);
            
            if (data.success) {
                let message = '✅ Limpieza completada!\n\n' + data.message;
                if (data.deleted > 0 && data.deleted_files) {
                    message += '\n\nArchivos eliminados:\n';
                    data.deleted_files.forEach(file => {
                        message += `- ${file.filename} (${file.date})\n`;
                    });
                }
                alert(message);
                location.reload(); // Recargar para actualizar la lista
            } else {
                alert('❌ Error en la limpieza:\n' + data.error);
            }
        })
        .catch(error => {
            console.error('Error completo:', error);
            alert('❌ Error de conexión o del servidor:\n' + error.message + '\n\nVerifique:\n' +
                  '- Que el archivo includes/backup_operations.php existe\n' +
                  '- Los permisos del directorio configbackup/\n' +
                  '- La consola del navegador para más detalles');
        })
        .finally(() => {
            // Restaurar botón
            button.disabled = false;
            button.innerHTML = originalText;        });
    }
}

function deleteBackup(filename, backupPath) {
    if (confirm(`¿Está seguro de que desea eliminar el backup "${filename}"?\n\nEsta acción no se puede deshacer.`)) {
        // Mostrar indicador de carga
        const button = event.target;
        const originalText = button.innerHTML;
        button.disabled = true;
        button.innerHTML = '⏳ Eliminando...';
        
        fetch('includes/backup_operations.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `action=delete_backup&filename=${encodeURIComponent(filename)}`
        })
        .then(response => {
            console.log('Response status:', response.status);
            console.log('Response headers:', response.headers.get('content-type'));
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            // Verificar que la respuesta es JSON
            const contentType = response.headers.get('content-type');
            if (!contentType || !contentType.includes('application/json')) {
                return response.text().then(text => {
                    console.error('Respuesta no-JSON recibida:', text);
                    throw new Error('El servidor no devolvió JSON válido. Respuesta: ' + text.substring(0, 200));
                });
            }
            
            return response.json();
        })
        .then(data => {
            console.log('Datos recibidos:', data);
            
            if (data.success) {
                alert(`✅ Backup eliminado exitosamente!\n\nArchivo: ${filename}`);
                location.reload(); // Recargar para actualizar la lista
            } else {
                alert('❌ Error al eliminar backup:\n' + data.error);
            }
        })
        .catch(error => {
            console.error('Error completo:', error);
            alert('❌ Error de conexión o del servidor:\n' + error.message + '\n\nVerifique:\n' +
                  '- Que el archivo includes/backup_operations.php existe\n' +
                  '- Los permisos del directorio configbackup/\n' +
                  '- La consola del navegador para más detalles');
        })
        .finally(() => {
            // Restaurar botón
            button.disabled = false;
            button.innerHTML = originalText;
        });
    }
}

// ===== FUNCIONES PARA GESTIÓN DEL LOGO =====

// Función para previsualizar el logo seleccionado
function previewLogo(input) {
    if (input.files && input.files[0]) {
        const file = input.files[0];
        
        // Validar tipo de archivo
        const allowedTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif'];
        if (!allowedTypes.includes(file.type)) {
            alert('❌ Por favor seleccione una imagen válida (PNG, JPG, GIF)');
            input.value = '';
            return;
        }
        
        // Validar tamaño (máximo 2MB)
        if (file.size > 2 * 1024 * 1024) {
            alert('❌ El archivo debe ser menor a 2MB');
            input.value = '';
            return;
        }
        
        // Crear preview
        const reader = new FileReader();
        reader.onload = function(e) {
            const preview = document.getElementById('logo-preview');
            const noLogo = document.querySelector('.no-logo');
            
            if (preview) {
                preview.src = e.target.result;
                preview.style.display = 'block';
            }
            
            if (noLogo) {
                noLogo.style.display = 'none';
            }
            
            // Actualizar información del archivo
            const logoInfo = document.querySelector('.logo-info small');
            if (logoInfo) {
                logoInfo.innerHTML = 'Nuevo logo: ' + file.name + ' (' + (file.size / 1024).toFixed(1) + ' KB)<br>' +
                    '<span style="color: var(--warning-color); font-weight: 600;">⚠️ Recuerde guardar la configuración para aplicar los cambios</span>';
            }
            
            // Mostrar notificación
            showLogoNotification('Logo seleccionado correctamente. Guarde la configuración para aplicar los cambios y actualizar el favicon.', 'info');
        };
        reader.readAsDataURL(file);
    }
}

// Función para mostrar notificaciones del logo
function showLogoNotification(message, type = 'info') {
    // Remover notificación anterior si existe
    const existingNotification = document.querySelector('.logo-notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // Crear nueva notificación
    const notification = document.createElement('div');
    notification.className = `logo-notification alert alert-${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 10000;
        max-width: 400px;
        animation: slideInRight 0.3s ease;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    `;
    notification.innerHTML = `
        <strong>${type === 'success' ? '✅' : type === 'warning' ? '⚠️' : 'ℹ️'}</strong> ${message}
        <button onclick="this.parentElement.remove()" style="float: right; background: none; border: none; font-size: 18px; cursor: pointer;">&times;</button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-remover después de 8 segundos
    setTimeout(() => {
        if (notification.parentElement) {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }
    }, 8000);
}

// Función para restaurar el logo original
function resetLogo() {
    if (confirm('¿Está seguro que desea restaurar el logo original?')) {
        // Resetear el input file
        const fileInput = document.getElementById('sistema_logo');
        fileInput.value = '';
        
        // Restaurar preview al logo original
        const preview = document.getElementById('logo-preview');
        if (preview) {
            preview.src = 'media/logo.png';
        }
        
        // Actualizar información
        const logoInfo = document.querySelector('.logo-info small');
        if (logoInfo) {
            logoInfo.innerHTML = 'Logo actual: logo.png';
        }
        
        showLogoNotification('Preview restaurado. Guarde la configuración para aplicar los cambios.', 'info');
    }
}

// Función para actualizar favicon dinámicamente
function updateFavicon(logoPath) {
    // Remover favicons existentes
    const existingFavicons = document.querySelectorAll('link[rel*="icon"]');
    existingFavicons.forEach(favicon => favicon.remove());
    
    // Crear nuevos favicons
    const faviconSizes = [
        { size: '16x16', rel: 'icon' },
        { size: '32x32', rel: 'icon' },
        { size: '', rel: 'shortcut icon' },
        { size: '', rel: 'apple-touch-icon' }
    ];
    
    faviconSizes.forEach(favicon => {
        const link = document.createElement('link');
        link.type = 'image/png';
        link.rel = favicon.rel;
        if (favicon.size) {
            link.sizes = favicon.size;
        }
        link.href = logoPath + '?v=' + Date.now(); // Cache busting
        document.head.appendChild(link);
    });
}

// Cerrar modal al hacer clic fuera
window.onclick = function(event) {
    const modal = document.getElementById('backupPreviewModal');
    if (event.target === modal) {
        modal.style.display = 'none';
    }
}
</script>
</body>
</html>