<?php
/**
 * Script de prueba para descargas de backup
 */

session_start();

// Simular datos de sesión para la prueba
$_SESSION['user_id'] = 1;
$_SESSION['usuario'] = 'admin';
$_SESSION['rol'] = 'admin';

echo "<h2>Prueba de Descarga de Backups</h2>";
echo "<p>Sesión activa: " . ($_SESSION['usuario'] ?? 'No hay sesión') . "</p>";
echo "<p>Rol: " . ($_SESSION['rol'] ?? 'Sin rol') . "</p>";

// Listar archivos de backup disponibles
$backup_dir = 'backups';
if (is_dir($backup_dir)) {
    $files = scandir($backup_dir);
    echo "<h3>Archivos de backup disponibles:</h3>";
    echo "<ul>";
    foreach ($files as $file) {
        if (pathinfo($file, PATHINFO_EXTENSION) === 'zip') {
            $download_url = "download_backup.php?file=" . urlencode($file);
            echo "<li>";
            echo "<strong>$file</strong> ";
            echo "(" . round(filesize("$backup_dir/$file") / 1024 / 1024, 2) . " MB) ";
            echo "- <a href='$download_url' target='_blank'>Descargar</a>";
            echo "</li>";
        }
    }
    echo "</ul>";
} else {
    echo "<p>No se encontró el directorio de backups.</p>";
}

echo "<hr>";
echo "<h3>Debug de Variables de Sesión:</h3>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";
?>
