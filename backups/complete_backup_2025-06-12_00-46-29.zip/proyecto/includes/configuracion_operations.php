<?php
/**
 * =====================================================
 * OPERACIONES DE CONFIGURACIÓN - SUITE AMBIENTAL
 * =====================================================
 * Maneja las operaciones AJAX para la configuración del sistema
 */

// ===== CONTROL DE SEGURIDAD Y SESIÓN =====
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verificar autenticación y permisos
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'admin') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit();
}

// Configurar respuesta JSON
header('Content-Type: application/json');

try {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'change_logo':
            handleLogoChange();
            break;
            
        case 'update_public_config':
            handlePublicConfigUpdate();
            break;
            
        case 'update_thresholds':
            handleThresholdsUpdate();
            break;
            
        case 'create_backup':
            handleCreateBackup();
            break;
            
        case 'clean_backups':
            handleCleanBackups();
            break;
            
        case 'delete_backup':
            handleDeleteBackup();
            break;
            
        case 'restore_config':
            handleRestoreConfig();
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Acción no válida']);
            break;
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Error del servidor: ' . $e->getMessage()]);
}

// ===== FUNCIÓN: CAMBIAR LOGO =====
function handleLogoChange() {
    try {
        if (!isset($_FILES['sistema_logo']) || $_FILES['sistema_logo']['error'] !== UPLOAD_ERR_OK) {
            echo json_encode(['success' => false, 'error' => 'No se recibió un archivo válido']);
            return;
        }
        
        $upload_file = $_FILES['sistema_logo'];
        $allowed_types = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif'];
        
        // Validar tipo de archivo
        if (!in_array($upload_file['type'], $allowed_types)) {
            echo json_encode(['success' => false, 'error' => 'Tipo de archivo no válido. Use PNG, JPG o GIF']);
            return;
        }
        
        // Validar tamaño (máximo 2MB)
        if ($upload_file['size'] > 2 * 1024 * 1024) {
            echo json_encode(['success' => false, 'error' => 'El archivo debe ser menor a 2MB']);
            return;
        }
        
        // Crear directorio media si no existe
        if (!is_dir('../media')) {
            mkdir('../media', 0755, true);
        }
        
        // Generar nombre único para el archivo
        $extension = pathinfo($upload_file['name'], PATHINFO_EXTENSION);
        $logo_filename = 'logo_' . time() . '.' . $extension;
        $logo_path = '../media/' . $logo_filename;
        
        // Mover archivo subido
        if (!move_uploaded_file($upload_file['tmp_name'], $logo_path)) {
            echo json_encode(['success' => false, 'error' => 'Error al subir el archivo']);
            return;
        }
        
        // Cargar configuración actual
        $config_actual = [];
        if (file_exists('../config.ini')) {
            $config_actual = parse_ini_file('../config.ini', true);
        }
        
        // Eliminar logo anterior si no es el por defecto
        $logo_anterior = $config_actual['sistema']['logo'] ?? '';
        if (!empty($logo_anterior) && $logo_anterior !== 'media/logo.png' && file_exists('../' . $logo_anterior)) {
            unlink('../' . $logo_anterior);
        }
        
        // Actualizar configuración
        $config_actual['sistema']['logo'] = 'media/' . $logo_filename;
        
        // Guardar configuración actualizada
        if (updateConfigFile($config_actual)) {
            echo json_encode([
                'success' => true, 
                'logo_path' => 'media/' . $logo_filename,
                'message' => 'Logo actualizado exitosamente'
            ]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Error al guardar la configuración']);
        }
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => 'Error: ' . $e->getMessage()]);
    }
}

// ===== FUNCIÓN: ACTUALIZAR CONFIGURACIÓN PÚBLICA =====
function handlePublicConfigUpdate() {
    try {
        // Validar datos recibidos
        $required_fields = ['publico_titulo', 'publico_subtitulo', 'publico_color_fondo', 'publico_color_secundario', 'publico_color_texto', 'publico_refresh_interval'];
        
        foreach ($required_fields as $field) {
            if (!isset($_POST[$field])) {
                echo json_encode(['success' => false, 'error' => "Campo requerido faltante: $field"]);
                return;
            }
        }
        
        // Validaciones
        $titulo = trim($_POST['publico_titulo']);
        $subtitulo = trim($_POST['publico_subtitulo']);
        $color_fondo = trim($_POST['publico_color_fondo']);
        $color_secundario = trim($_POST['publico_color_secundario']);
        $color_texto = trim($_POST['publico_color_texto']);
        $refresh_interval = intval($_POST['publico_refresh_interval']);
        
        $errores = [];
        
        if (strlen($titulo) < 3 || strlen($titulo) > 50) {
            $errores[] = 'El título debe tener entre 3 y 50 caracteres';
        }
        if (strlen($subtitulo) < 3 || strlen($subtitulo) > 80) {
            $errores[] = 'El subtítulo debe tener entre 3 y 80 caracteres';
        }
        if (!preg_match('/^#[0-9A-Fa-f]{6}$/', $color_fondo)) {
            $errores[] = 'Color de fondo no válido';
        }
        if (!preg_match('/^#[0-9A-Fa-f]{6}$/', $color_secundario)) {
            $errores[] = 'Color secundario no válido';
        }
        if (!preg_match('/^#[0-9A-Fa-f]{6}$/', $color_texto)) {
            $errores[] = 'Color de texto no válido';
        }
        if ($refresh_interval < 60 || $refresh_interval > 3600) {
            $errores[] = 'Intervalo de actualización debe estar entre 60 y 3600 segundos';
        }
        
        if (!empty($errores)) {
            echo json_encode(['success' => false, 'error' => implode(', ', $errores)]);
            return;
        }
        
        // Cargar configuración actual
        $config_actual = [];
        if (file_exists('../config.ini')) {
            $config_actual = parse_ini_file('../config.ini', true);
        }
        
        // Actualizar sección pública
        $config_actual['publico'] = [
            'titulo' => $titulo,
            'subtitulo' => $subtitulo,
            'color_fondo' => $color_fondo,
            'color_secundario' => $color_secundario,
            'color_texto' => $color_texto,
            'refresh_interval' => $refresh_interval
        ];
        
        // Guardar configuración
        if (updateConfigFile($config_actual)) {
            echo json_encode(['success' => true, 'message' => 'Configuración del monitor público actualizada exitosamente']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Error al guardar la configuración']);
        }
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => 'Error: ' . $e->getMessage()]);
    }
}

// ===== FUNCIÓN: ACTUALIZAR UMBRALES AMBIENTALES =====
function handleThresholdsUpdate() {
    try {
        // Validar datos recibidos
        $required_fields = ['temperatura_max', 'humedad_max', 'ruido_max', 'co2_max', 'lux_min'];
        
        foreach ($required_fields as $field) {
            if (!isset($_POST[$field])) {
                echo json_encode(['success' => false, 'error' => "Campo requerido faltante: $field"]);
                return;
            }
        }
        
        $temperatura_max = floatval($_POST['temperatura_max']);
        $humedad_max = floatval($_POST['humedad_max']);
        $ruido_max = floatval($_POST['ruido_max']);
        $co2_max = intval($_POST['co2_max']);
        $lux_min = intval($_POST['lux_min']);
        
        $errores = [];
        
        if ($temperatura_max < 15 || $temperatura_max > 50) {
            $errores[] = 'Temperatura máxima debe estar entre 15°C y 50°C';
        }
        if ($humedad_max < 30 || $humedad_max > 90) {
            $errores[] = 'Humedad máxima debe estar entre 30% y 90%';
        }
        if ($ruido_max < 20 || $ruido_max > 100) {
            $errores[] = 'Ruido máximo debe estar entre 20dB y 100dB';
        }
        if ($co2_max < 300 || $co2_max > 5000) {
            $errores[] = 'CO2 máximo debe estar entre 300ppm y 5000ppm';
        }
        if ($lux_min < 50 || $lux_min > 1000) {
            $errores[] = 'Iluminación mínima debe estar entre 50lux y 1000lux';
        }
        
        if (!empty($errores)) {
            echo json_encode(['success' => false, 'error' => implode(', ', $errores)]);
            return;
        }
        
        // Cargar configuración actual
        $config_actual = [];
        if (file_exists('../config.ini')) {
            $config_actual = parse_ini_file('../config.ini', true);
        }
        
        // Actualizar sección de referencias
        $config_actual['referencias'] = [
            'temperatura_max' => $temperatura_max,
            'humedad_max' => $humedad_max,
            'ruido_max' => $ruido_max,
            'co2_max' => $co2_max,
            'lux_min' => $lux_min
        ];
        
        // Guardar configuración
        if (updateConfigFile($config_actual)) {
            echo json_encode(['success' => true, 'message' => 'Umbrales ambientales actualizados exitosamente']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Error al guardar la configuración']);
        }
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => 'Error: ' . $e->getMessage()]);
    }
}

// ===== FUNCIÓN: CREAR BACKUP MANUAL =====
function handleCreateBackup() {
    try {
        if (!file_exists('../config.ini')) {
            echo json_encode(['success' => false, 'error' => 'No existe el archivo config.ini']);
            return;
        }
        
        // Crear directorio de backup si no existe
        if (!is_dir('../configbackup')) {
            mkdir('../configbackup', 0755, true);
        }
        
        $backup_filename = 'config_back_' . date('y_m_d_H_i') . '.ini';
        $backup_path = '../configbackup/' . $backup_filename;
        
        if (copy('../config.ini', $backup_path)) {
            $file_size = filesize($backup_path);
            echo json_encode([
                'success' => true,
                'filename' => $backup_filename,
                'size' => $file_size,
                'timestamp' => date('Y-m-d H:i:s'),
                'message' => 'Backup creado exitosamente'
            ]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Error al crear el backup']);
        }
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => 'Error: ' . $e->getMessage()]);
    }
}

// ===== FUNCIÓN: LIMPIAR BACKUPS ANTIGUOS =====
function handleCleanBackups() {
    try {
        if (!is_dir('../configbackup')) {
            echo json_encode(['success' => false, 'error' => 'Directorio de backups no existe']);
            return;
        }
        
        $backup_files = [];
        $files = scandir('../configbackup');
        
        foreach ($files as $file) {
            if (preg_match('/^config_back_.+\.ini$/', $file)) {
                $backup_files[] = [
                    'filename' => $file,
                    'path' => '../configbackup/' . $file,
                    'date' => filemtime('../configbackup/' . $file),
                    'size' => filesize('../configbackup/' . $file)
                ];
            }
        }
        
        // Ordenar por fecha (más reciente primero)
        usort($backup_files, function($a, $b) {
            return $b['date'] - $a['date'];
        });
        
        $total_files = count($backup_files);
        $files_to_keep = 10;
        $deleted_count = 0;
        $deleted_files = [];
        
        if ($total_files > $files_to_keep) {
            // Eliminar todos los archivos excepto los 10 más recientes
            for ($i = $files_to_keep; $i < $total_files; $i++) {
                $file_to_delete = $backup_files[$i];
                if (unlink($file_to_delete['path'])) {
                    $deleted_count++;
                    $deleted_files[] = [
                        'filename' => $file_to_delete['filename'],
                        'date' => date('d/m/Y H:i:s', $file_to_delete['date'])
                    ];
                }
            }
        }
        
        $message = $deleted_count > 0 
            ? "Se eliminaron $deleted_count archivos, manteniendo los 10 más recientes" 
            : "No hay archivos para eliminar. Se mantienen los últimos 10 backups";
        
        echo json_encode([
            'success' => true,
            'deleted' => $deleted_count,
            'message' => $message,
            'deleted_files' => $deleted_files
        ]);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => 'Error: ' . $e->getMessage()]);
    }
}

// ===== FUNCIÓN: ELIMINAR BACKUP =====
function handleDeleteBackup() {
    try {
        $filename = $_POST['filename'] ?? '';
        
        if (empty($filename)) {
            echo json_encode(['success' => false, 'error' => 'Nombre de archivo no especificado']);
            return;
        }
        
        $backup_path = '../configbackup/' . $filename;
        
        if (!file_exists($backup_path)) {
            echo json_encode(['success' => false, 'error' => 'El archivo no existe']);
            return;
        }
        
        if (unlink($backup_path)) {
            echo json_encode(['success' => true, 'message' => 'Backup eliminado exitosamente']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Error al eliminar el archivo']);
        }
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => 'Error: ' . $e->getMessage()]);
    }
}

// ===== FUNCIÓN: RESTAURAR CONFIGURACIÓN =====
function handleRestoreConfig() {
    try {
        $backup_file = $_POST['backup_file'] ?? '';
        
        if (empty($backup_file)) {
            echo json_encode(['success' => false, 'error' => 'Archivo de backup no especificado']);
            return;
        }
        
        $backup_path = '../configbackup/' . $backup_file;
        
        if (!file_exists($backup_path)) {
            echo json_encode(['success' => false, 'error' => 'El archivo de backup no existe']);
            return;
        }
        
        // Crear backup de la configuración actual antes de restaurar
        if (file_exists('../config.ini')) {
            $current_backup = '../configbackup/config_back_before_restore_' . date('y_m_d_H_i') . '.ini';
            copy('../config.ini', $current_backup);
        }
        
        // Restaurar configuración
        if (copy($backup_path, '../config.ini')) {
            echo json_encode(['success' => true, 'message' => 'Configuración restaurada exitosamente']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Error al restaurar la configuración']);
        }
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => 'Error: ' . $e->getMessage()]);
    }
}

// ===== FUNCIÓN AUXILIAR: ACTUALIZAR ARCHIVO DE CONFIGURACIÓN =====
function updateConfigFile($config_array) {
    try {
        $config_content = "; Configuración del Sistema de Monitoreo Ambiental\n";
        $config_content .= "; Actualizado el " . date('Y-m-d H:i:s') . " por " . $_SESSION['usuario'] . "\n\n";
        
        foreach ($config_array as $section_name => $section_data) {
            $config_content .= "[$section_name]\n";
            
            if ($section_name === 'referencias') {
                // Sección de referencias sin comillas
                foreach ($section_data as $key => $value) {
                    $config_content .= "$key = $value\n";
                }
            } else {
                // Otras secciones con comillas
                foreach ($section_data as $key => $value) {
                    $config_content .= "$key = \"$value\"\n";
                }
            }
            $config_content .= "\n";
        }
        
        return file_put_contents('../config.ini', $config_content) !== false;
        
    } catch (Exception $e) {
        return false;
    }
}
?>
