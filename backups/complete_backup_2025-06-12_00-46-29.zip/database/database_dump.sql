-- =====================================================
-- BACKUP DE BASE DE DATOS - SUITE AMBIENTAL
-- Generado el: 2025-06-12 00:46:31
-- Base de datos: suite_ambiental
-- Usuario: admin
-- =====================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = '+00:00';

-- Estructura de tabla `configuracion`
DROP TABLE IF EXISTS `configuracion`;
CREATE TABLE `configuracion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `seccion` varchar(50) NOT NULL COMMENT 'Sección de configuración',
  `clave` varchar(100) NOT NULL COMMENT 'Clave de configuración',
  `valor` text NOT NULL COMMENT 'Valor de configuración',
  `descripcion` text DEFAULT NULL COMMENT 'Descripción del parámetro',
  `tipo` enum('string','int','float','boolean','json') DEFAULT 'string' COMMENT 'Tipo de dato',
  `fecha_creacion` timestamp NULL DEFAULT current_timestamp(),
  `fecha_actualizacion` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_seccion_clave` (`seccion`,`clave`),
  KEY `idx_seccion` (`seccion`),
  KEY `idx_tipo` (`tipo`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Tabla de configuración del sistema';

-- Datos de la tabla `configuracion`
INSERT INTO `configuracion` (`id`, `seccion`, `clave`, `valor`, `descripcion`, `tipo`, `fecha_creacion`, `fecha_actualizacion`) VALUES
('1', 'sistema', 'version', '1.0', 'Versión del sistema Suite Ambiental', 'string', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('2', 'sistema', 'nombre', 'Suite Ambiental', 'Nombre del sistema', 'string', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('3', 'sistema', 'timezone', '+01:00', 'Zona horaria del sistema (España UTC+1)', 'string', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('4', 'alertas', 'temperatura_max', '25', 'Temperatura máxima antes de alerta (°C)', 'float', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('5', 'alertas', 'humedad_max', '48', 'Humedad relativa máxima antes de alerta (%)', 'float', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('6', 'alertas', 'ruido_max', '35', 'Nivel de ruido máximo antes de alerta (dB)', 'float', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('7', 'alertas', 'co2_max', '1000', 'Concentración de CO2 máxima antes de alerta (ppm)', 'int', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('8', 'alertas', 'lux_min', '195', 'Iluminación mínima antes de alerta (lux)', 'int', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('9', 'mantenimiento', 'dias_retencion_registros', '180', 'Días de retención para registros de sensores', 'int', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('10', 'mantenimiento', 'dias_retencion_logs', '90', 'Días de retención para logs del sistema', 'int', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('11', 'api', 'max_registros_por_minuto', '60', 'Máximo de registros por minuto por dispositivo', 'int', '2025-06-10 16:43:03', '2025-06-10 16:43:03'),
('12', 'api', 'timeout_dispositivo_horas', '1', 'Horas para considerar dispositivo inactivo', 'int', '2025-06-10 16:43:03', '2025-06-10 16:43:03');

-- Estructura de tabla `dispositivos`
DROP TABLE IF EXISTS `dispositivos`;
CREATE TABLE `dispositivos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL COMMENT 'Identificador único del dispositivo',
  `ubicacion` varchar(255) NOT NULL COMMENT 'Ubicación física del dispositivo',
  `direccion_ip` varchar(45) NOT NULL COMMENT 'Dirección IP del dispositivo (IPv4/IPv6)',
  `direccion_mac` varchar(17) NOT NULL COMMENT 'Dirección MAC del dispositivo',
  `descripcion` text DEFAULT NULL COMMENT 'Descripción adicional del dispositivo',
  `fecha_instalacion` date DEFAULT NULL COMMENT 'Fecha de instalación del dispositivo',
  `fecha_creacion` timestamp NULL DEFAULT current_timestamp() COMMENT 'Fecha de registro en el sistema',
  `fecha_actualizacion` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `activo` tinyint(1) DEFAULT 1 COMMENT 'Si el dispositivo está activo',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nombre` (`nombre`),
  KEY `idx_ubicacion` (`ubicacion`),
  KEY `idx_ip` (`direccion_ip`),
  KEY `idx_activo` (`activo`),
  KEY `idx_fecha_creacion` (`fecha_creacion`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Tabla de dispositivos/sensores Arduino registrados';

-- Datos de la tabla `dispositivos`
INSERT INTO `dispositivos` (`id`, `nombre`, `ubicacion`, `direccion_ip`, `direccion_mac`, `descripcion`, `fecha_instalacion`, `fecha_creacion`, `fecha_actualizacion`, `activo`) VALUES
('1', 'Sensor01', 'Sala Steam', '192.168.1.101', '00:1B:44:11:3A:B7', 'Sensor principal de monitoreo en área administrativa', '2025-06-01', '2025-06-10 16:43:03', '2025-06-11 18:31:18', '1'),
('2', 'Sensor02', 'Laboratorio de Investigación', '192.168.1.102', '00:1B:44:11:3A:B8', 'Sensor de laboratorio con control ambiental específico', '2025-06-01', '2025-06-10 16:43:03', '2025-06-10 16:43:03', '1'),
('3', 'Sensor03', 'Almacén - Planta Baja', '192.168.1.103', '00:1B:44:11:3A:B9', 'Sensor de almacén para control de inventario y condiciones', '2025-06-02', '2025-06-10 16:43:03', '2025-06-10 16:43:03', '1'),
('4', 'Sensor04', 'Sala de Reuniones Ejecutiva', '192.168.1.104', '00:1B:44:11:3A:BA', 'Sensor de sala de reuniones para máximo confort', '2025-06-02', '2025-06-10 16:43:03', '2025-06-10 16:43:03', '1'),
('5', 'Sensor05', 'Pasillo Principal - Recepción', '192.168.1.105', '00:1B:44:11:3A:BB', 'Sensor de pasillo para monitoreo general de tránsito', '2025-06-03', '2025-06-10 16:43:03', '2025-06-10 16:43:03', '1');

-- Estructura de tabla `logs_sistema`
DROP TABLE IF EXISTS `logs_sistema`;
CREATE TABLE `logs_sistema` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nivel` enum('DEBUG','INFO','WARNING','ERROR','CRITICAL') NOT NULL DEFAULT 'INFO',
  `categoria` varchar(50) NOT NULL COMMENT 'Categoría del log (login, api, admin, etc)',
  `mensaje` text NOT NULL COMMENT 'Mensaje del log',
  `usuario_id` int(11) DEFAULT NULL COMMENT 'Usuario relacionado (si aplica)',
  `direccion_ip` varchar(45) DEFAULT NULL COMMENT 'Dirección IP del cliente',
  `user_agent` text DEFAULT NULL COMMENT 'User Agent del navegador',
  `datos_adicionales` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Datos adicionales en formato JSON' CHECK (json_valid(`datos_adicionales`)),
  `fecha_hora` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_nivel_fecha` (`nivel`,`fecha_hora`),
  KEY `idx_categoria_fecha` (`categoria`,`fecha_hora`),
  KEY `idx_usuario_fecha` (`usuario_id`,`fecha_hora`),
  KEY `idx_fecha_hora` (`fecha_hora`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Tabla de logs del sistema';

-- Datos de la tabla `logs_sistema`
INSERT INTO `logs_sistema` (`id`, `nivel`, `categoria`, `mensaje`, `usuario_id`, `direccion_ip`, `user_agent`, `datos_adicionales`, `fecha_hora`) VALUES
('1', 'INFO', 'usuario', 'Usuario creado', '1', NULL, NULL, '{\"usuario\": \"admin\", \"rol\": \"admin\"}', '2025-06-10 16:43:02'),
('2', 'INFO', 'usuario', 'Usuario creado', '2', NULL, NULL, '{\"usuario\": \"operador1\", \"rol\": \"operador\"}', '2025-06-10 16:43:02'),
('3', 'INFO', 'usuario', 'Usuario creado', '3', NULL, NULL, '{\"usuario\": \"demo\", \"rol\": \"operador\"}', '2025-06-10 16:43:02'),
('4', 'INFO', 'dispositivo', 'Dispositivo modificado', NULL, NULL, NULL, '{\"dispositivo\": \"Sensor01\", \"cambios\": {\"activo_anterior\": 1, \"activo_nuevo\": 1, \"ubicacion_anterior\": \"Oficina Principal - Administración\", \"ubicacion_nueva\": \"SteamRoom\"}}', '2025-06-11 13:03:38'),
('5', 'INFO', 'usuario', 'Usuario creado', '4', NULL, NULL, '{\"usuario\": \"demo\", \"rol\": \"operador\"}', '2025-06-11 13:26:33'),
('6', 'INFO', 'dispositivo', 'Dispositivo modificado', NULL, NULL, NULL, '{\"dispositivo\": \"Sensor01\", \"cambios\": {\"activo_anterior\": 1, \"activo_nuevo\": 1, \"ubicacion_anterior\": \"SteamRoom\", \"ubicacion_nueva\": \"Sala de Superación\"}}', '2025-06-11 13:27:25'),
('7', 'INFO', 'usuario', 'Usuario creado', '5', NULL, NULL, '{\"usuario\": \"demo\", \"rol\": \"operador\"}', '2025-06-11 17:44:58'),
('8', 'INFO', 'usuario', 'Usuario creado', '6', NULL, NULL, '{\"usuario\": \"mmontarroso\", \"rol\": \"operador\"}', '2025-06-11 18:30:44'),
('9', 'INFO', 'dispositivo', 'Dispositivo modificado', NULL, NULL, NULL, '{\"dispositivo\": \"Sensor01\", \"cambios\": {\"activo_anterior\": 1, \"activo_nuevo\": 1, \"ubicacion_anterior\": \"Sala de Superación\", \"ubicacion_nueva\": \"Sala Steam\"}}', '2025-06-11 18:31:18');

-- Estructura de tabla `registros`
DROP TABLE IF EXISTS `registros`;
CREATE TABLE `registros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sensor_id` varchar(50) DEFAULT NULL COMMENT 'ID del sensor que envía los datos',
  `temperatura` decimal(5,2) DEFAULT NULL COMMENT 'Temperatura en grados Celsius (-99.99 a 999.99)',
  `humedad` decimal(5,2) DEFAULT NULL COMMENT 'Humedad relativa en porcentaje (0.00 a 100.00)',
  `ruido` decimal(5,2) DEFAULT NULL COMMENT 'Nivel de ruido en decibelios (0.00 a 150.00)',
  `co2` int(11) DEFAULT NULL COMMENT 'Concentración de CO2 en ppm (0 a 50000)',
  `lux` int(11) DEFAULT NULL COMMENT 'Iluminación en lux (0 a 100000)',
  `fecha_hora` datetime DEFAULT NULL COMMENT 'Fecha y hora del registro',
  `alerta_temperatura` tinyint(1) GENERATED ALWAYS AS (`temperatura` > 25) STORED COMMENT 'Alerta por temperatura alta',
  `alerta_humedad` tinyint(1) GENERATED ALWAYS AS (`humedad` > 48) STORED COMMENT 'Alerta por humedad alta',
  `alerta_ruido` tinyint(1) GENERATED ALWAYS AS (`ruido` > 35) STORED COMMENT 'Alerta por ruido alto',
  `alerta_co2` tinyint(1) GENERATED ALWAYS AS (`co2` > 1000) STORED COMMENT 'Alerta por CO2 alto',
  `alerta_iluminacion` tinyint(1) GENERATED ALWAYS AS (`lux` < 195) STORED COMMENT 'Alerta por iluminación baja',
  `estado` enum('normal','alerta','critico') GENERATED ALWAYS AS (case when (`temperatura` > 25) + (`humedad` > 48) + (`ruido` > 35) + (`co2` > 1000) + (`lux` < 195) >= 3 then 'critico' when (`temperatura` > 25) + (`humedad` > 48) + (`ruido` > 35) + (`co2` > 1000) + (`lux` < 195) >= 1 then 'alerta' else 'normal' end) STORED COMMENT 'Estado general del registro',
  PRIMARY KEY (`id`),
  KEY `idx_sensor_fecha` (`sensor_id`,`fecha_hora`),
  KEY `idx_fecha_hora` (`fecha_hora`),
  KEY `idx_sensor_id` (`sensor_id`),
  KEY `idx_estado` (`estado`),
  KEY `idx_temperatura` (`temperatura`),
  KEY `idx_humedad` (`humedad`),
  KEY `idx_ruido` (`ruido`),
  KEY `idx_co2` (`co2`),
  KEY `idx_lux` (`lux`),
  KEY `idx_alerta_temp` (`alerta_temperatura`,`fecha_hora`),
  KEY `idx_alerta_hum` (`alerta_humedad`,`fecha_hora`),
  KEY `idx_alerta_ruido` (`alerta_ruido`,`fecha_hora`),
  KEY `idx_alerta_co2` (`alerta_co2`,`fecha_hora`),
  KEY `idx_alerta_luz` (`alerta_iluminacion`,`fecha_hora`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Tabla de registros de datos de sensores ambientales';

-- Datos de la tabla `registros`
INSERT INTO `registros` (`id`, `sensor_id`, `temperatura`, `humedad`, `ruido`, `co2`, `lux`, `fecha_hora`, `alerta_temperatura`, `alerta_humedad`, `alerta_ruido`, `alerta_co2`, `alerta_iluminacion`, `estado`) VALUES
('1', 'Sensor01', '23.50', '45.20', '32.10', '450', '250', '2025-06-10 15:43:03', '0', '0', '0', '0', '0', 'normal'),
('2', 'Sensor01', '23.30', '44.80', '31.80', '435', '255', '2025-06-10 15:28:03', '0', '0', '0', '0', '0', 'normal'),
('3', 'Sensor01', '23.70', '45.60', '32.40', '465', '248', '2025-06-10 15:13:03', '0', '0', '0', '0', '0', 'normal'),
('4', 'Sensor01', '23.10', '44.10', '31.20', '420', '262', '2025-06-10 14:58:03', '0', '0', '0', '0', '0', 'normal'),
('5', 'Sensor02', '26.80', '52.30', '38.50', '1200', '180', '2025-06-10 15:38:03', '1', '1', '1', '1', '1', 'critico'),
('6', 'Sensor02', '27.10', '53.10', '39.20', '1250', '175', '2025-06-10 15:23:03', '1', '1', '1', '1', '1', 'critico'),
('7', 'Sensor02', '26.50', '51.80', '37.80', '1180', '185', '2025-06-10 15:08:03', '1', '1', '1', '1', '1', 'critico'),
('8', 'Sensor02', '26.90', '52.50', '38.80', '1220', '178', '2025-06-10 14:53:03', '1', '1', '1', '1', '1', 'critico'),
('9', 'Sensor03', '22.10', '41.70', '28.90', '380', '320', '2025-06-10 15:33:03', '0', '0', '0', '0', '0', 'normal'),
('10', 'Sensor03', '21.80', '41.20', '28.10', '365', '325', '2025-06-10 15:18:03', '0', '0', '0', '0', '0', 'normal'),
('11', 'Sensor03', '22.30', '42.10', '29.50', '395', '315', '2025-06-10 15:03:03', '0', '0', '0', '0', '0', 'normal'),
('12', 'Sensor03', '22.00', '41.80', '28.70', '375', '322', '2025-06-10 14:48:03', '0', '0', '0', '0', '0', 'normal'),
('13', 'Sensor04', '24.30', '47.80', '35.20', '680', '210', '2025-06-10 15:35:03', '0', '0', '1', '0', '0', 'alerta'),
('14', 'Sensor04', '24.60', '48.20', '36.10', '695', '205', '2025-06-10 15:20:03', '0', '1', '1', '0', '0', 'alerta'),
('15', 'Sensor04', '24.10', '47.30', '34.80', '665', '215', '2025-06-10 15:05:03', '0', '0', '0', '0', '0', 'normal'),
('16', 'Sensor04', '24.40', '47.90', '35.50', '678', '208', '2025-06-10 14:50:03', '0', '0', '1', '0', '0', 'alerta');

-- Estructura de tabla `usuarios`
DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL COMMENT 'Nombre de usuario único',
  `contrasena` varchar(255) NOT NULL COMMENT 'Contraseña del usuario',
  `rol` enum('admin','operador') NOT NULL DEFAULT 'operador' COMMENT 'Rol del usuario',
  `fecha_creacion` timestamp NULL DEFAULT current_timestamp() COMMENT 'Fecha de creación del usuario',
  `fecha_ultimo_acceso` timestamp NULL DEFAULT NULL COMMENT 'Último acceso al sistema',
  `activo` tinyint(1) DEFAULT 1 COMMENT 'Si el usuario está activo',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`),
  KEY `idx_rol` (`rol`),
  KEY `idx_activo` (`activo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Tabla de usuarios del sistema con autenticación local';

-- Datos de la tabla `usuarios`
INSERT INTO `usuarios` (`id`, `usuario`, `contrasena`, `rol`, `fecha_creacion`, `fecha_ultimo_acceso`, `activo`) VALUES
('1', 'admin', 'admin123', 'admin', '2025-06-10 16:43:02', '2025-06-10 16:43:02', '1'),
('5', 'demo', 'demo123', 'operador', '2025-06-11 17:44:58', NULL, '1'),
('6', 'mmontarroso', 'password123', 'operador', '2025-06-11 18:30:44', NULL, '1');

-- Estructura de tabla `v_alertas_por_hora`
DROP TABLE IF EXISTS `v_alertas_por_hora`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_alertas_por_hora` AS select cast(`registros`.`fecha_hora` as date) AS `fecha`,hour(`registros`.`fecha_hora`) AS `hora`,count(0) AS `total_registros`,sum(`registros`.`alerta_temperatura`) AS `alertas_temperatura`,sum(`registros`.`alerta_humedad`) AS `alertas_humedad`,sum(`registros`.`alerta_ruido`) AS `alertas_ruido`,sum(`registros`.`alerta_co2`) AS `alertas_co2`,sum(`registros`.`alerta_iluminacion`) AS `alertas_iluminacion`,sum(case when `registros`.`estado` = 'critico' then 1 else 0 end) AS `registros_criticos`,sum(case when `registros`.`estado` = 'alerta' then 1 else 0 end) AS `registros_alerta`,round(sum(case when `registros`.`estado` in ('critico','alerta') then 1 else 0 end) / count(0) * 100,2) AS `porcentaje_alertas` from `registros` group by cast(`registros`.`fecha_hora` as date),hour(`registros`.`fecha_hora`);

-- Datos de la tabla `v_alertas_por_hora`
INSERT INTO `v_alertas_por_hora` (`fecha`, `hora`, `total_registros`, `alertas_temperatura`, `alertas_humedad`, `alertas_ruido`, `alertas_co2`, `alertas_iluminacion`, `registros_criticos`, `registros_alerta`, `porcentaje_alertas`) VALUES
('2025-06-10', '14', '4', '1', '1', '2', '1', '1', '1', '1', '50.00'),
('2025-06-10', '15', '12', '3', '4', '5', '3', '3', '3', '2', '41.67');

-- Estructura de tabla `v_dispositivos_estado`
DROP TABLE IF EXISTS `v_dispositivos_estado`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_dispositivos_estado` AS select `d`.`id` AS `id`,`d`.`nombre` AS `nombre`,`d`.`ubicacion` AS `ubicacion`,`d`.`direccion_ip` AS `direccion_ip`,`d`.`direccion_mac` AS `direccion_mac`,`d`.`activo` AS `dispositivo_activo`,`r`.`temperatura` AS `temperatura`,`r`.`humedad` AS `humedad`,`r`.`ruido` AS `ruido`,`r`.`co2` AS `co2`,`r`.`lux` AS `lux`,`r`.`fecha_hora` AS `ultima_lectura`,`r`.`estado` AS `ultimo_estado`,case when `r`.`fecha_hora` > current_timestamp() - interval 1 hour then 'activo' when `r`.`fecha_hora` > current_timestamp() - interval 24 hour then 'inactivo_reciente' else 'inactivo' end AS `estado_conexion`,timestampdiff(MINUTE,`r`.`fecha_hora`,current_timestamp()) AS `minutos_desde_ultima_lectura` from (`dispositivos` `d` left join (select `registros`.`sensor_id` AS `sensor_id`,`registros`.`temperatura` AS `temperatura`,`registros`.`humedad` AS `humedad`,`registros`.`ruido` AS `ruido`,`registros`.`co2` AS `co2`,`registros`.`lux` AS `lux`,`registros`.`fecha_hora` AS `fecha_hora`,`registros`.`estado` AS `estado`,row_number() over ( partition by `registros`.`sensor_id` order by `registros`.`fecha_hora` desc) AS `rn` from `registros`) `r` on(`d`.`nombre` = `r`.`sensor_id` and `r`.`rn` = 1)) where `d`.`activo` = 1;

-- Datos de la tabla `v_dispositivos_estado`
INSERT INTO `v_dispositivos_estado` (`id`, `nombre`, `ubicacion`, `direccion_ip`, `direccion_mac`, `dispositivo_activo`, `temperatura`, `humedad`, `ruido`, `co2`, `lux`, `ultima_lectura`, `ultimo_estado`, `estado_conexion`, `minutos_desde_ultima_lectura`) VALUES
('1', 'Sensor01', 'Sala Steam', '192.168.1.101', '00:1B:44:11:3A:B7', '1', '23.50', '45.20', '32.10', '450', '250', '2025-06-10 15:43:03', 'normal', 'inactivo', '1983'),
('2', 'Sensor02', 'Laboratorio de Investigación', '192.168.1.102', '00:1B:44:11:3A:B8', '1', '26.80', '52.30', '38.50', '1200', '180', '2025-06-10 15:38:03', 'critico', 'inactivo', '1988'),
('3', 'Sensor03', 'Almacén - Planta Baja', '192.168.1.103', '00:1B:44:11:3A:B9', '1', '22.10', '41.70', '28.90', '380', '320', '2025-06-10 15:33:03', 'normal', 'inactivo', '1993'),
('4', 'Sensor04', 'Sala de Reuniones Ejecutiva', '192.168.1.104', '00:1B:44:11:3A:BA', '1', '24.30', '47.80', '35.20', '680', '210', '2025-06-10 15:35:03', 'alerta', 'inactivo', '1991'),
('5', 'Sensor05', 'Pasillo Principal - Recepción', '192.168.1.105', '00:1B:44:11:3A:BB', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'inactivo', NULL);

-- Estructura de tabla `v_estadisticas_diarias`
DROP TABLE IF EXISTS `v_estadisticas_diarias`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_estadisticas_diarias` AS select `registros`.`sensor_id` AS `sensor_id`,cast(`registros`.`fecha_hora` as date) AS `fecha`,count(0) AS `total_registros`,avg(`registros`.`temperatura`) AS `temp_promedio`,min(`registros`.`temperatura`) AS `temp_minima`,max(`registros`.`temperatura`) AS `temp_maxima`,avg(`registros`.`humedad`) AS `hum_promedio`,min(`registros`.`humedad`) AS `hum_minima`,max(`registros`.`humedad`) AS `hum_maxima`,avg(`registros`.`ruido`) AS `ruido_promedio`,min(`registros`.`ruido`) AS `ruido_minimo`,max(`registros`.`ruido`) AS `ruido_maximo`,avg(`registros`.`co2`) AS `co2_promedio`,min(`registros`.`co2`) AS `co2_minimo`,max(`registros`.`co2`) AS `co2_maximo`,avg(`registros`.`lux`) AS `lux_promedio`,min(`registros`.`lux`) AS `lux_minimo`,max(`registros`.`lux`) AS `lux_maximo`,sum(`registros`.`alerta_temperatura`) AS `alertas_temperatura`,sum(`registros`.`alerta_humedad`) AS `alertas_humedad`,sum(`registros`.`alerta_ruido`) AS `alertas_ruido`,sum(`registros`.`alerta_co2`) AS `alertas_co2`,sum(`registros`.`alerta_iluminacion`) AS `alertas_iluminacion`,sum(case when `registros`.`estado` = 'critico' then 1 else 0 end) AS `registros_criticos`,sum(case when `registros`.`estado` = 'alerta' then 1 else 0 end) AS `registros_alerta`,sum(case when `registros`.`estado` = 'normal' then 1 else 0 end) AS `registros_normales` from `registros` group by `registros`.`sensor_id`,cast(`registros`.`fecha_hora` as date);

-- Datos de la tabla `v_estadisticas_diarias`
INSERT INTO `v_estadisticas_diarias` (`sensor_id`, `fecha`, `total_registros`, `temp_promedio`, `temp_minima`, `temp_maxima`, `hum_promedio`, `hum_minima`, `hum_maxima`, `ruido_promedio`, `ruido_minimo`, `ruido_maximo`, `co2_promedio`, `co2_minimo`, `co2_maximo`, `lux_promedio`, `lux_minimo`, `lux_maximo`, `alertas_temperatura`, `alertas_humedad`, `alertas_ruido`, `alertas_co2`, `alertas_iluminacion`, `registros_criticos`, `registros_alerta`, `registros_normales`) VALUES
('Sensor01', '2025-06-10', '4', '23.400000', '23.10', '23.70', '44.925000', '44.10', '45.60', '31.875000', '31.20', '32.40', '442.5000', '420', '465', '253.7500', '248', '262', '0', '0', '0', '0', '0', '0', '0', '4'),
('Sensor02', '2025-06-10', '4', '26.825000', '26.50', '27.10', '52.425000', '51.80', '53.10', '38.575000', '37.80', '39.20', '1212.5000', '1180', '1250', '179.5000', '175', '185', '4', '4', '4', '4', '4', '4', '0', '0'),
('Sensor03', '2025-06-10', '4', '22.050000', '21.80', '22.30', '41.700000', '41.20', '42.10', '28.800000', '28.10', '29.50', '378.7500', '365', '395', '320.5000', '315', '325', '0', '0', '0', '0', '0', '0', '0', '4'),
('Sensor04', '2025-06-10', '4', '24.350000', '24.10', '24.60', '47.800000', '47.30', '48.20', '35.400000', '34.80', '36.10', '679.5000', '665', '695', '209.5000', '205', '215', '0', '1', '3', '0', '0', '0', '3', '1');

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
