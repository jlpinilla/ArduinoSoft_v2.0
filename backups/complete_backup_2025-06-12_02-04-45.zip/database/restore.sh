#!/bin/bash
# Script de restauración de base de datos
# Suite Ambiental - Generado el 2025-06-12 02:04:47

echo "Restaurando base de datos..."
mysql -u [USUARIO] -p [BASE_DE_DATOS] < database_dump.sql
echo "Restauración completada"
