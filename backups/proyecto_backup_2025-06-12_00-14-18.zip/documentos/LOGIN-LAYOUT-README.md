# Documentación de Estilos para Páginas de Login

## Estructura de Archivos CSS

El sistema de estilos para las páginas de login ha sido consolidado para mejorar la organización y mantenibilidad:

1. **styles.css**: 
   - Archivo principal con estilos base para toda la aplicación
   - Contiene variables CSS globales y componentes comunes

2. **login-pages-consolidated.css**: 
   - Archivo único con todos los estilos para las páginas de login
   - Combina los estilos específicos para index.php y callback.php
   - Contiene todas las optimizaciones para diseño horizontal compacto
   - Incluye media queries para responsividad completa
   - Incorpora correcciones de compatibilidad entre navegadores

### Archivos anteriores (ya no utilizados)
- ~~login-pages.css~~
- ~~login-pages-extra.css~~
- ~~css-fixes.css~~

## Diseño Horizontal vs Vertical

Ambas páginas (index.php y callback.php) utilizan ahora un diseño **horizontal** con las siguientes características:

### Características Comunes
- Layout basado en grid con proporción 0.6fr / 1px / 1.4fr
- Sección izquierda con logo y título de la aplicación
- Divisor vertical para separar las secciones
- Diseño compacto optimizado para eficiencia de espacio

### index.php (Página de Login)
- Formulario de acceso a la derecha con campos de usuario y contraseña
- Optimizado para entrada rápida de credenciales
- Mensajes del sistema en la sección derecha

### callback.php (Página de Bienvenida)
- Mensaje de bienvenida en la sección izquierda
- Contador regresivo visual en la sección derecha
- Acceso directo al panel principal
- Información del usuario compacta
- Alertas optimizadas y redimensionadas

## Optimizaciones Específicas

### Mejoras en index.php
- Reducción del tamaño del logo a 80x80px
- Formulario horizontal con etiquetas compactas (18% / 82%)
- Campos de formulario con altura optimizada (32px)
- Badge de validación CSS redimensionado
- Ajustes de márgenes y espaciado para reducir altura total

### Mejoras en callback.php
- Rediseño completo del contador visual
- Barra de progreso más compacta (6px)
- Botones de acceso directo optimizados en tamaño
- Información del usuario integrada en panel izquierdo
- Nueva barra de información del sistema con versión
- Estructura con mejor aprovechamiento del espacio

## Responsividad

Los estilos consolidados incluyen media queries para garantizar una experiencia óptima en todos los dispositivos:

- **Pantalla grande (max-width: 900px)**:
  - Ajustes sutiles de tamaño y espaciado
  - Reducción del tamaño del logo a 60x60px
  
- **Tablet (max-width: 768px)**:
  - Cambio a layout vertical completo
  - Redisposición de elementos para mejor flujo
  - Ajustes de tamaño de fuentes y espaciado
  
- **Móvil (max-width: 480px)**:
  - Máxima compactación de elementos
  - Optimización para pantallas pequeñas
  - Reorganización de elementos

- **Móvil (max-width: 480px)**:
  - Mayor reducción de elementos gráficos
  - Optimización para pantallas pequeñas
  - Mejoras de accesibilidad táctil

## Mantenimiento

Para realizar cambios o actualizaciones:

1. Modificaciones visuales generales: editar `login-pages.css`
2. Ajustes de layout horizontal: editar `login-pages-extra.css`
3. Correcciones de compatibilidad: editar `css-fixes.css`

Evite modificar directamente `styles.css` para cambios específicos de las páginas de login.
