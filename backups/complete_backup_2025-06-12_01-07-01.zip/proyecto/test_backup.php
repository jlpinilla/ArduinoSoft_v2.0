<?php
/**
 * Script de prueba para el sistema de backup
 */

// Configurar variables de sesión para simular usuario administrador
session_start();
$_SESSION['usuario'] = 'admin';
$_SESSION['rol'] = 'admin';

require_once 'includes/backup_manager.php';

echo "=== PRUEBA DEL SISTEMA DE BACKUP ===\n\n";

try {
    $backupManager = new BackupManager();
    echo "✓ BackupManager inicializado correctamente\n";
    
    // Probar backup del proyecto
    echo "\n--- Iniciando backup del proyecto ---\n";
    $result = $backupManager->createProjectBackup(true, false);
    
    if ($result['success']) {
        echo "✓ Backup del proyecto creado exitosamente\n";
        echo "  Archivo: " . $result['filename'] . "\n";
        echo "  Tamaño: " . round($result['size'] / 1024 / 1024, 2) . " MB\n";
        echo "  Ruta: " . $result['path'] . "\n";
    } else {
        echo "✗ Error creando backup del proyecto\n";
    }
    
} catch (Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
    echo "Trace: " . $e->getTraceAsString() . "\n";
}

echo "\n=== FIN DE LA PRUEBA ===\n";
?>
